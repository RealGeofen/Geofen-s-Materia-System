# Changelog

## 1.0.0

- Completed the full Materia equipment framework.
- Added AP, configurable levels, equipment growth rates, level-specific effects/text/affixes/grants/link/suppression overrides, and mastery behaviors.
- Added generic specialized linked Support modifier rules and linked granted abilities.
- Added temporary D&D5e Item/feature grants with source tracking and automatic cleanup.
- Added equipment-wide and per-slot Materia category/UUID restrictions plus equipped, attuned, rarity, and property activation requirements.
- Added compact visual socket layouts, category-colored sockets, orientation controls, active/inactive/suppressed status badges, and diagnostic reasons.
- Added GM Materia Library settings menu with create, duplicate, edit, copy UUID, JSON import, and JSON export workflows.
- Added GM Materia Manager & Recovery settings menu with AP awards, installed-Materia inspection, diagnostics, host repair, rebuild, and inventory recovery tools.
- Added automatic migration/rebuild for existing enabled host Items.
- Added equipment deletion recovery and Actor duplication/import ownership retargeting.
- Hardened stacked Materia restoration so individually progressed Materia do not lose AP by merging into incompatible quantity stacks.
- Preserved arbitrary multi-slot link graphs, UUID matching, Active Effect suppression, inventory transfer, permission controls, collapsible/scrollable configuration, and description-only terminology customization.
- Preserved exact compatibility targeting for Foundry VTT 14.365 and D&D5e 5.3.3.
