const MODULE_ID = "geofen-materia-system";
const VERSION = "0.1.1";
const MAX_SLOTS = 8;
const HOST_TYPES = new Set(["weapon", "equipment"]);
const INTERNAL_OPTION = MODULE_ID;

const DEFAULT_MATERIA = Object.freeze({
  enabled: false,
  category: "magic",
  allowed: "both",
  slotText: "",
  prefix: "",
  suffix: "",
  copyEffects: true
});

const DEFAULT_HOST = Object.freeze({
  enabled: false,
  slotCount: 0,
  slots: [],
  baseName: "",
  baseDescription: ""
});

function log(...args) {
  console.log(`${MODULE_ID} |`, ...args);
}

function warn(...args) {
  console.warn(`${MODULE_ID} |`, ...args);
}

function notify(message, type = "info") {
  ui.notifications?.[type]?.(message);
}

function clone(value) {
  return foundry.utils.deepClone(value);
}

function clampSlots(value) {
  const numeric = Number.parseInt(value ?? 0, 10);
  if (!Number.isFinite(numeric)) return 0;
  return Math.min(MAX_SLOTS, Math.max(0, numeric));
}

function getMateria(item) {
  return foundry.utils.mergeObject(clone(DEFAULT_MATERIA), clone(item?.getFlag(MODULE_ID, "materia") ?? {}), {
    inplace: false,
    recursive: true
  });
}

function getHost(item) {
  const raw = foundry.utils.mergeObject(clone(DEFAULT_HOST), clone(item?.getFlag(MODULE_ID, "host") ?? {}), {
    inplace: false,
    recursive: true
  });
  raw.slotCount = clampSlots(raw.slotCount);
  raw.slots = Array.from({ length: raw.slotCount }, (_, index) => raw.slots?.[index] ?? null);
  return raw;
}

function escapeHTML(value) {
  const div = document.createElement("div");
  div.textContent = String(value ?? "");
  return div.innerHTML;
}

function stripGeneratedDescription(html) {
  return String(html ?? "")
    .replace(/\s*<!-- GEOFEN_MATERIA_START -->[\s\S]*?<!-- GEOFEN_MATERIA_END -->\s*/g, "")
    .trim();
}

function canEdit(item) {
  return Boolean(item?.isOwner ?? item?.testUserPermission?.(game.user, "OWNER"));
}

function isItemDocument(document) {
  return document?.documentName === "Item";
}

function isSupportedHost(item) {
  return isItemDocument(item) && HOST_TYPES.has(item.type);
}

function materiaAllowedOn(materia, host) {
  if (materia.allowed === "both") return true;
  return materia.allowed === host.type;
}

function slotDisplay(slot) {
  if (!slot?.uuid) return { name: "Empty", img: "icons/svg/item-bag.svg", uuid: null };
  return {
    name: slot.name || slot.uuid,
    img: slot.img || "icons/svg/item-bag.svg",
    uuid: slot.uuid
  };
}

function allHostItems() {
  const items = [];
  for (const item of game.items ?? []) if (isSupportedHost(item)) items.push(item);
  for (const actor of game.actors ?? []) {
    for (const item of actor.items ?? []) if (isSupportedHost(item)) items.push(item);
  }
  return items;
}

function isAlreadySlotted(hostItem, materiaUuid, targetIndex = -1) {
  if (!materiaUuid) return false;
  const actor = hostItem.actor;
  const hosts = actor ? actor.items.filter(isSupportedHost) : [hostItem];
  for (const candidate of hosts) {
    const host = getHost(candidate);
    if (!host.enabled) continue;
    for (let i = 0; i < host.slots.length; i++) {
      if (candidate.id === hostItem.id && i === targetIndex) continue;
      if (host.slots[i]?.uuid === materiaUuid) return candidate;
    }
  }
  return false;
}

function generatedEffects(item) {
  return item.effects?.filter(effect => effect.getFlag(MODULE_ID, "generated") === true) ?? [];
}

async function deleteGeneratedEffects(item) {
  const ids = generatedEffects(item).map(effect => effect.id);
  if (!ids.length) return;
  await item.deleteEmbeddedDocuments("ActiveEffect", ids, { [INTERNAL_OPTION]: { internal: true } });
}

function generatedDescription(host, resolvedSlots) {
  if (!host.enabled || host.slotCount < 1) return "";
  const lines = [];
  for (let i = 0; i < host.slotCount; i++) {
    const entry = resolvedSlots[i];
    if (!entry?.materia) {
      lines.push(`<p><strong>Slot ${i + 1}:</strong> Empty</p>`);
      continue;
    }
    const text = String(entry.materia.slotText ?? "").trim();
    const suffix = text ? ` — ${escapeHTML(text)}` : "";
    lines.push(`<p><strong>Slot ${i + 1}:</strong> ${escapeHTML(entry.item.name)}${suffix}</p>`);
  }
  return `\n<!-- GEOFEN_MATERIA_START -->\n<section class="geofen-materia-description" data-geofen-materia-generated="true">\n<h3>Materia</h3>\n${lines.join("\n")}\n</section>\n<!-- GEOFEN_MATERIA_END -->`;
}

function generatedName(host, resolvedSlots) {
  const baseName = String(host.baseName ?? "").trim();
  const prefixes = [];
  const suffixes = [];
  for (const entry of resolvedSlots) {
    if (!entry?.materia) continue;
    const prefix = String(entry.materia.prefix ?? "").trim();
    const suffix = String(entry.materia.suffix ?? "").trim();
    if (prefix) prefixes.push(prefix);
    if (suffix) suffixes.push(suffix);
  }
  return [prefixes.join(" "), baseName, suffixes.length ? suffixes.join(" ") : ""]
    .filter(Boolean)
    .join(" ")
    .replace(/\s+/g, " ")
    .trim();
}

function prepareEffectClone(effect, sourceMateria, hostItem) {
  if (effect.getFlag(MODULE_ID, "generated")) return null;
  if (effect.disabled) return null;

  const data = effect.toObject();
  delete data._id;
  delete data._stats;

  data.flags ??= {};
  data.flags[MODULE_ID] = {
    generated: true,
    sourceMateriaUuid: sourceMateria.uuid,
    sourceHostUuid: hostItem.uuid
  };
  data.origin = sourceMateria.uuid;

  const applicableType = effect.system?.applicableType ?? (effect.type === "enchantment" ? "Item" : "Actor");
  if (effect.type === "enchantment" || applicableType === "Item") {
    data.type = "enchantment";
    data.transfer = false;
    data.system ??= {};
    data.system.applicableType = "Item";
    if ("isApplied" in data.system) data.system.isApplied = true;
  } else {
    data.transfer = true;
    data.system ??= {};
    data.system.applicableType = "Actor";
  }

  return data;
}

async function resolveSlots(hostItem, host) {
  const resolved = [];
  let changedSnapshots = false;

  for (let i = 0; i < host.slotCount; i++) {
    const slot = host.slots[i];
    if (!slot?.uuid) {
      resolved.push(null);
      continue;
    }

    let source = null;
    try {
      source = await fromUuid(slot.uuid);
    } catch (error) {
      warn(`Could not resolve Materia UUID ${slot.uuid}`, error);
    }

    if (!isItemDocument(source)) {
      resolved.push(null);
      continue;
    }

    const materia = getMateria(source);
    if (!materia.enabled || !materiaAllowedOn(materia, hostItem)) {
      resolved.push(null);
      continue;
    }

    if (slot.name !== source.name || slot.img !== source.img) {
      host.slots[i] = { uuid: source.uuid, name: source.name, img: source.img };
      changedSnapshots = true;
    }

    resolved.push({ item: source, materia });
  }

  return { resolved, changedSnapshots };
}

async function rebuildHost(hostItem, { render = false } = {}) {
  if (!isSupportedHost(hostItem) || !canEdit(hostItem)) return;
  const host = getHost(hostItem);

  host.baseName ||= String(hostItem.name ?? "");
  host.baseDescription ||= stripGeneratedDescription(hostItem.system?.description?.value ?? "");

  await deleteGeneratedEffects(hostItem);

  if (!host.enabled) {
    const currentDescription = hostItem.system?.description?.value ?? "";
    const updates = {
      name: host.baseName || hostItem.name,
      "system.description.value": host.baseDescription || stripGeneratedDescription(currentDescription),
      [`flags.${MODULE_ID}.host`]: host
    };
    await hostItem.update(updates, { [INTERNAL_OPTION]: { internal: true } });
    if (render) hostItem.sheet?.render({ force: true });
    return;
  }

  const { resolved } = await resolveSlots(hostItem, host);
  const effectData = [];
  for (const entry of resolved) {
    if (!entry?.materia?.copyEffects) continue;
    for (const effect of entry.item.effects ?? []) {
      const data = prepareEffectClone(effect, entry.item, hostItem);
      if (data) effectData.push(data);
    }
  }

  const nextName = generatedName(host, resolved) || host.baseName || hostItem.name;
  const nextDescription = `${host.baseDescription}${generatedDescription(host, resolved)}`;

  await hostItem.update({
    name: nextName,
    "system.description.value": nextDescription,
    [`flags.${MODULE_ID}.host`]: host
  }, { [INTERNAL_OPTION]: { internal: true } });

  if (effectData.length) {
    await hostItem.createEmbeddedDocuments("ActiveEffect", effectData, { [INTERNAL_OPTION]: { internal: true } });
  }

  if (render) hostItem.sheet?.render({ force: true });
}

async function refreshHostsReferencing(materiaUuid, { clearMissing = false } = {}) {
  const jobs = [];
  for (const item of allHostItems()) {
    if (!canEdit(item)) continue;
    const host = getHost(item);
    if (!host.enabled) continue;
    let touched = false;
    for (let i = 0; i < host.slots.length; i++) {
      if (host.slots[i]?.uuid !== materiaUuid) continue;
      touched = true;
      if (clearMissing) host.slots[i] = null;
    }
    if (!touched) continue;
    if (clearMissing) {
      await item.setFlag(MODULE_ID, "host", host);
    }
    jobs.push(rebuildHost(item, { render: true }));
  }
  await Promise.allSettled(jobs);
}

async function saveHostConfiguration(item, panel) {
  const host = getHost(item);
  const enabled = Boolean(panel.querySelector('[data-field="host-enabled"]')?.checked);
  const slotCount = clampSlots(panel.querySelector('[data-field="slot-count"]')?.value ?? host.slotCount);

  if (!host.baseName) host.baseName = item.name;
  if (!host.baseDescription) host.baseDescription = stripGeneratedDescription(item.system?.description?.value ?? "");

  host.enabled = enabled;
  host.slotCount = slotCount;
  host.slots = Array.from({ length: slotCount }, (_, index) => host.slots[index] ?? null);

  await item.setFlag(MODULE_ID, "host", host);
  await rebuildHost(item, { render: true });
  notify(`Materia configuration saved for ${host.baseName || item.name}.`);
}

async function saveMateriaConfiguration(item, panel) {
  const materia = getMateria(item);
  materia.enabled = Boolean(panel.querySelector('[data-field="materia-enabled"]')?.checked);
  materia.category = panel.querySelector('[data-field="materia-category"]')?.value ?? "magic";
  materia.allowed = panel.querySelector('[data-field="materia-allowed"]')?.value ?? "both";
  materia.slotText = panel.querySelector('[data-field="materia-text"]')?.value ?? "";
  materia.prefix = panel.querySelector('[data-field="materia-prefix"]')?.value ?? "";
  materia.suffix = panel.querySelector('[data-field="materia-suffix"]')?.value ?? "";
  materia.copyEffects = Boolean(panel.querySelector('[data-field="materia-copy-effects"]')?.checked);

  await item.setFlag(MODULE_ID, "materia", materia);
  await refreshHostsReferencing(item.uuid);
  item.sheet?.render({ force: true });
  notify(`${item.name} Materia configuration saved.`);
}

async function removeSlot(item, slotIndex) {
  const host = getHost(item);
  if (slotIndex < 0 || slotIndex >= host.slotCount) return;
  host.slots[slotIndex] = null;
  await item.setFlag(MODULE_ID, "host", host);
  await rebuildHost(item, { render: true });
}

function extractDropData(event) {
  const candidates = [
    event.dataTransfer?.getData("text/plain"),
    event.dataTransfer?.getData("application/json")
  ].filter(Boolean);

  for (const raw of candidates) {
    try {
      const data = JSON.parse(raw);
      if (data && typeof data === "object") return data;
    } catch (_error) {
      // Ignore non-JSON drag payloads.
    }
  }
  return null;
}

async function slotMateria(hostItem, slotIndex, event) {
  event.preventDefault();
  event.stopPropagation();

  if (!canEdit(hostItem)) return;
  const data = extractDropData(event);
  if (!data) return notify("That drop did not contain a Foundry Item.", "warn");

  let source = null;
  try {
    if (data.uuid) source = await fromUuid(data.uuid);
    else if (data.type === "Item" && data.data?._id) source = game.items.get(data.data._id);
  } catch (error) {
    warn("Failed to resolve dropped Item", error);
  }

  if (!isItemDocument(source)) return notify("Only Items can be slotted as Materia.", "warn");
  const materia = getMateria(source);
  if (!materia.enabled) return notify(`${source.name} is not configured as Materia.`, "warn");
  if (!materiaAllowedOn(materia, hostItem)) {
    return notify(`${source.name} is not allowed on ${hostItem.type} items.`, "warn");
  }

  const duplicateHost = isAlreadySlotted(hostItem, source.uuid, slotIndex);
  if (duplicateHost) {
    return notify(`${source.name} is already slotted in ${duplicateHost.name}.`, "warn");
  }

  const host = getHost(hostItem);
  if (!host.enabled || slotIndex < 0 || slotIndex >= host.slotCount) return;
  host.slots[slotIndex] = { uuid: source.uuid, name: source.name, img: source.img };
  await hostItem.setFlag(MODULE_ID, "host", host);
  await rebuildHost(hostItem, { render: true });
  notify(`${source.name} slotted into Slot ${slotIndex + 1}.`);
}

function hostSection(item, host, editable) {
  if (!isSupportedHost(item)) return "";
  const disabled = editable ? "" : "disabled";
  const options = Array.from({ length: MAX_SLOTS + 1 }, (_, i) =>
    `<option value="${i}" ${host.slotCount === i ? "selected" : ""}>${i}</option>`
  ).join("");

  const slots = host.enabled && host.slotCount > 0
    ? `<div class="gms-slots">${host.slots.map((slot, index) => {
        const display = slotDisplay(slot);
        return `<div class="gms-slot ${slot?.uuid ? "filled" : "empty"}" data-slot-index="${index}" title="Drag a configured Materia Item here">
          <img src="${escapeHTML(display.img)}" alt="" />
          <div class="gms-slot-copy">
            <strong>Slot ${index + 1}</strong>
            <span>${escapeHTML(display.name)}</span>
          </div>
          ${slot?.uuid && editable ? `<button type="button" class="gms-icon-button" data-action="remove-slot" data-slot-index="${index}" title="Remove Materia"><i class="fa-solid fa-xmark"></i></button>` : ""}
        </div>`;
      }).join("")}</div>`
    : `<p class="gms-muted">Enable Materia and choose at least one slot to create drop targets.</p>`;

  return `<section class="gms-card gms-host-card">
    <header><i class="fa-solid fa-gem"></i><strong>Equipment Materia</strong></header>
    <div class="gms-grid gms-grid-2">
      <label class="gms-check"><input type="checkbox" data-field="host-enabled" ${host.enabled ? "checked" : ""} ${disabled}/> Enable Materia on this equipment</label>
      <label>Slots
        <select data-field="slot-count" ${disabled}>${options}</select>
      </label>
    </div>
    ${slots}
    ${editable ? `<button type="button" data-action="save-host"><i class="fa-solid fa-floppy-disk"></i> Save Equipment Materia</button>` : ""}
  </section>`;
}

function materiaSection(item, materia, editable) {
  const disabled = editable ? "" : "disabled";
  const categories = [
    ["magic", "Green — Magic"],
    ["support", "Blue — Support"],
    ["command", "Yellow — Command"],
    ["independent", "Purple — Independent"],
    ["summon", "Red — Summon"],
    ["other", "Other"]
  ];
  const categoryOptions = categories.map(([value, label]) =>
    `<option value="${value}" ${materia.category === value ? "selected" : ""}>${label}</option>`
  ).join("");
  const allowed = [
    ["both", "Weapons & Equipment"],
    ["weapon", "Weapons Only"],
    ["equipment", "Equipment/Armor Only"]
  ].map(([value, label]) => `<option value="${value}" ${materia.allowed === value ? "selected" : ""}>${label}</option>`).join("");

  return `<section class="gms-card gms-materia-card">
    <header><i class="fa-solid fa-circle-dot"></i><strong>Materia Item</strong></header>
    <label class="gms-check"><input type="checkbox" data-field="materia-enabled" ${materia.enabled ? "checked" : ""} ${disabled}/> This Item is Materia</label>
    <div class="gms-grid gms-grid-2">
      <label>Materia Type<select data-field="materia-category" ${disabled}>${categoryOptions}</select></label>
      <label>Allowed Equipment<select data-field="materia-allowed" ${disabled}>${allowed}</select></label>
      <label>Prefix<input type="text" data-field="materia-prefix" value="${escapeHTML(materia.prefix)}" placeholder="Flaming" ${disabled}/></label>
      <label>Suffix<input type="text" data-field="materia-suffix" value="${escapeHTML(materia.suffix)}" placeholder="of Embers" ${disabled}/></label>
    </div>
    <label>Slot Description Text<textarea data-field="materia-text" rows="2" placeholder="Flames dance along the weapon's edge." ${disabled}>${escapeHTML(materia.slotText)}</textarea></label>
    <label class="gms-check"><input type="checkbox" data-field="materia-copy-effects" ${materia.copyEffects ? "checked" : ""} ${disabled}/> Copy this Materia's Active Effects onto slotted equipment</label>
    <p class="gms-muted">Standard Actor effects are transferred through the equipment and follow D&D5e equipped/attunement suppression. Item/enchantment effects are copied as item enchantments where supported by D&D5e.</p>
    ${editable ? `<button type="button" data-action="save-materia"><i class="fa-solid fa-floppy-disk"></i> Save Materia Item</button>` : ""}
  </section>`;
}

function buildPanel(item) {
  const editable = canEdit(item);
  const host = getHost(item);
  const materia = getMateria(item);
  const wrapper = document.createElement("section");
  wrapper.className = "geofen-materia-panel";
  wrapper.dataset.itemUuid = item.uuid;
  wrapper.innerHTML = `<details ${host.enabled || materia.enabled ? "open" : ""}>
    <summary><i class="fa-solid fa-gem"></i> Geofen's Materia System <span class="gms-version">v${VERSION}</span></summary>
    <div class="gms-panel-body">
      ${hostSection(item, host, editable)}
      ${materiaSection(item, materia, editable)}
    </div>
  </details>`;
  return wrapper;
}

function bindPanel(item, panel) {
  panel.querySelector('[data-action="save-host"]')?.addEventListener("click", () => saveHostConfiguration(item, panel));
  panel.querySelector('[data-action="save-materia"]')?.addEventListener("click", () => saveMateriaConfiguration(item, panel));

  for (const button of panel.querySelectorAll('[data-action="remove-slot"]')) {
    button.addEventListener("click", event => {
      event.preventDefault();
      event.stopPropagation();
      removeSlot(item, Number(button.dataset.slotIndex));
    });
  }

  for (const slot of panel.querySelectorAll(".gms-slot")) {
    slot.addEventListener("dragover", event => {
      event.preventDefault();
      slot.classList.add("dragover");
    });
    slot.addEventListener("dragleave", () => slot.classList.remove("dragover"));
    slot.addEventListener("drop", event => {
      slot.classList.remove("dragover");
      slotMateria(item, Number(slot.dataset.slotIndex), event);
    });
  }
}

function injectPanel(application, element) {
  if (game.system.id !== "dnd5e") return;
  const item = application.document ?? application.item ?? application.object;
  if (!isItemDocument(item)) return;
  if (element.querySelector?.(".geofen-materia-panel")) return;

  const panel = buildPanel(item);
  // ApplicationV2 item sheets are assembled from independent render parts/forms.
  // Append to the sheet content root rather than nesting inside one system-owned form.
  element.append(panel);
  bindPanel(item, panel);
}

Hooks.once("init", () => {
  log(`Initializing v${VERSION}`);
});

Hooks.once("ready", async () => {
  if (game.system.id !== "dnd5e") {
    notify("Geofen's : Materia System requires the D&D5e system.", "error");
    return;
  }

  const module = game.modules.get(MODULE_ID);
  if (module) {
    module.api = {
      rebuildHost,
      refreshHostsReferencing,
      getHost,
      getMateria,
      version: VERSION
    };
  }
  log(`Ready on Foundry ${game.version}, D&D5e ${game.system.version}.`);
});

Hooks.on("renderApplicationV2", (application, element) => {
  try {
    injectPanel(application, element);
  } catch (error) {
    console.error(`${MODULE_ID} | Failed to render Materia panel`, error);
  }
});

Hooks.on("preUpdateItem", (item, changes, options) => {
  if (options?.[INTERNAL_OPTION]?.internal) return;
  if (!isSupportedHost(item)) return;
  const host = getHost(item);
  if (!host.enabled) return;

  if (Object.prototype.hasOwnProperty.call(changes, "name")) {
    host.baseName = String(changes.name ?? "");
    foundry.utils.setProperty(changes, `flags.${MODULE_ID}.host.baseName`, host.baseName);
  }

  const description = foundry.utils.getProperty(changes, "system.description.value");
  if (description !== undefined) {
    host.baseDescription = stripGeneratedDescription(description);
    foundry.utils.setProperty(changes, "system.description.value", host.baseDescription);
    foundry.utils.setProperty(changes, `flags.${MODULE_ID}.host.baseDescription`, host.baseDescription);
  }
});

Hooks.on("updateItem", async (item, changes, options, userId) => {
  if (options?.[INTERNAL_OPTION]?.internal) return;
  if (userId !== game.user.id) return;

  const materia = getMateria(item);
  if (materia.enabled) await refreshHostsReferencing(item.uuid);

  if (isSupportedHost(item) && getHost(item).enabled) {
    const relevant = Object.prototype.hasOwnProperty.call(changes, "name")
      || foundry.utils.getProperty(changes, "system.description.value") !== undefined
      || foundry.utils.getProperty(changes, "system.equipped") !== undefined
      || foundry.utils.getProperty(changes, "system.attuned") !== undefined;
    if (relevant) await rebuildHost(item, { render: false });
  }
});

Hooks.on("deleteItem", async (item, options, userId) => {
  if (userId !== game.user.id) return;
  if (getMateria(item).enabled) await refreshHostsReferencing(item.uuid, { clearMissing: true });
});

for (const hookName of ["createActiveEffect", "updateActiveEffect", "deleteActiveEffect"]) {
  Hooks.on(hookName, async (effect, _changesOrOptions, optionsOrUserId, maybeUserId) => {
    const userId = maybeUserId ?? optionsOrUserId;
    const options = maybeUserId ? optionsOrUserId : _changesOrOptions;
    if (options?.[INTERNAL_OPTION]?.internal) return;
    if (userId && userId !== game.user.id) return;
    if (effect.getFlag?.(MODULE_ID, "generated")) return;
    const parent = effect.parent;
    if (!isItemDocument(parent)) return;
    if (!getMateria(parent).enabled) return;
    await refreshHostsReferencing(parent.uuid);
  });
}
