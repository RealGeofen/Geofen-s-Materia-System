const MODULE_ID = "geofen-materia-system";
const VERSION = "1.0.0";
const MAX_SLOTS = 8;
const MAX_LEVELS = 10;
const HOST_TYPES = new Set(["weapon", "equipment"]);
const INTERNAL_OPTION = MODULE_ID;
const CATEGORY_VALUES = ["magic", "support", "command", "independent", "summon", "other"];
const CATEGORY_LABELS = Object.freeze({
  magic: "Green — Magic",
  support: "Blue — Support",
  command: "Yellow — Command",
  independent: "Purple — Independent",
  summon: "Red — Summon",
  other: "Other"
});
const RARITY_ORDER = Object.freeze(["common", "uncommon", "rare", "veryRare", "legendary", "artifact"]);
const EFFECT_MODES = Object.freeze({ custom: 0, multiply: 1, add: 2, downgrade: 3, upgrade: 4, override: 5 });

const DEFAULT_LEVEL_PROFILE = Object.freeze({
  threshold: 0,
  slotText: "",
  linkedText: "",
  prefix: "",
  suffix: "",
  linkedPrefix: "",
  linkedSuffix: "",
  effectUuids: "",
  grantUuids: "",
  effectTiming: "inherit",
  linkRequirement: "inherit",
  partnerUuids: "",
  suppressionBehavior: "inherit",
  suppressionScope: "inherit",
  suppressionRequirement: "inherit",
  suppressionUuids: ""
});

const DEFAULT_MATERIA = Object.freeze({
  enabled: false,
  category: "magic",
  allowed: "both",
  slotText: "",
  prefix: "",
  suffix: "",
  copyEffects: true,
  effectTiming: "always",
  grantUuids: "",
  linkedText: "",
  linkedPrefix: "",
  linkedSuffix: "",
  linkedGrantUuids: "",
  linkRequirement: "any",
  partnerUuids: "",
  suppressEffects: false,
  suppressionScope: "linked-group",
  suppressionRequirement: "any",
  suppressionUuids: "",
  linkedModifiers: [],
  progression: {
    enabled: false,
    ap: 0,
    maxLevel: 5,
    masteryBehavior: "none",
    masteredHandled: false,
    levels: []
  }
});

const DEFAULT_SLOT_RULE = Object.freeze({
  category: "any",
  uuids: ""
});

const DEFAULT_HOST = Object.freeze({
  enabled: false,
  slotCount: 0,
  slots: [],
  links: [],
  baseName: "",
  baseDescription: "",
  growthMode: "normal",
  customGrowth: 1,
  appearance: "cards",
  orientation: "vertical",
  allowedCategories: [],
  allowedUuids: "",
  requireEquipped: false,
  requireAttuned: false,
  minimumRarity: "any",
  requiredProperties: "",
  slotRules: [],
  statuses: []
});

function log(...args) {
  console.log(`${MODULE_ID} |`, ...args);
}

function warn(...args) {
  console.warn(`${MODULE_ID} |`, ...args);
}

function notify(message, type = "info") {
  ui.notifications?.[type]?.(message);
}

function captureOpenSections(panel) {
  return new Set(
    [...(panel?.querySelectorAll?.("details[data-collapse-section][open]") ?? [])]
      .map(details => details.dataset.collapseSection)
      .filter(Boolean)
  );
}

function isSectionOpen(openSections, section) {
  return Boolean(openSections?.has?.(section));
}

function clone(value) {
  return foundry.utils.deepClone(value);
}

function clampSlots(value) {
  const numeric = Number.parseInt(value ?? 0, 10);
  if (!Number.isFinite(numeric)) return 0;
  return Math.min(MAX_SLOTS, Math.max(0, numeric));
}

function clampLevel(value) {
  const numeric = Number.parseInt(value ?? 1, 10);
  if (!Number.isFinite(numeric)) return 1;
  return Math.min(MAX_LEVELS, Math.max(1, numeric));
}

function normalizeLevelProfiles(levels, maxLevel) {
  const source = Array.isArray(levels) ? levels : [];
  const defaults = [0, 500, 1500, 3000, 6000, 10000, 15000, 21000, 28000, 36000];
  const normalized = [];
  for (let i = 0; i < maxLevel; i++) {
    const profile = foundry.utils.mergeObject(clone(DEFAULT_LEVEL_PROFILE), clone(source[i] ?? {}), {
      inplace: false,
      recursive: true
    });
    const threshold = Number(profile.threshold ?? defaults[i] ?? 0);
    profile.threshold = Number.isFinite(threshold) ? Math.max(0, Math.floor(threshold)) : (defaults[i] ?? 0);
    for (const key of ["slotText", "linkedText", "prefix", "suffix", "linkedPrefix", "linkedSuffix", "effectUuids", "grantUuids", "partnerUuids", "suppressionUuids"]) {
      profile[key] = String(profile[key] ?? "");
    }
    profile.effectTiming = ["inherit", "always", "linked"].includes(profile.effectTiming) ? profile.effectTiming : "inherit";
    profile.linkRequirement = ["inherit", "any", "non-support", ...CATEGORY_VALUES].includes(profile.linkRequirement) ? profile.linkRequirement : "inherit";
    profile.suppressionBehavior = ["inherit", "on", "off"].includes(profile.suppressionBehavior) ? profile.suppressionBehavior : "inherit";
    profile.suppressionScope = ["inherit", "linked-group", "equipment"].includes(profile.suppressionScope) ? profile.suppressionScope : "inherit";
    profile.suppressionRequirement = ["inherit", "any", "non-support", ...CATEGORY_VALUES].includes(profile.suppressionRequirement) ? profile.suppressionRequirement : "inherit";
    normalized.push(profile);
  }
  // Thresholds must be non-decreasing so level resolution is deterministic.
  for (let i = 1; i < normalized.length; i++) normalized[i].threshold = Math.max(normalized[i].threshold, normalized[i - 1].threshold);
  return normalized;
}

function normalizeModifierRules(rules) {
  const source = Array.isArray(rules) ? rules : [];
  return source.slice(0, 8).map(rule => {
    const mode = String(rule?.mode ?? "override");
    return {
      path: String(rule?.path ?? "").trim(),
      mode: Object.prototype.hasOwnProperty.call(EFFECT_MODES, mode) ? mode : "override",
      value: String(rule?.value ?? "")
    };
  }).filter(rule => rule.path || rule.value);
}

function normalizeMateriaData(source) {
  const raw = foundry.utils.mergeObject(clone(DEFAULT_MATERIA), clone(source ?? {}), {
    inplace: false,
    recursive: true
  });
  raw.enabled = Boolean(raw.enabled);
  raw.category = CATEGORY_VALUES.includes(raw.category) ? raw.category : "magic";
  raw.allowed = ["both", "weapon", "equipment"].includes(raw.allowed) ? raw.allowed : "both";
  raw.copyEffects = Boolean(raw.copyEffects);
  raw.effectTiming = raw.effectTiming === "linked" ? "linked" : "always";
  raw.linkRequirement = ["any", "non-support", ...CATEGORY_VALUES].includes(raw.linkRequirement) ? raw.linkRequirement : "any";
  raw.suppressEffects = Boolean(raw.suppressEffects);
  raw.suppressionScope = raw.suppressionScope === "equipment" ? "equipment" : "linked-group";
  raw.suppressionRequirement = ["any", "non-support", ...CATEGORY_VALUES].includes(raw.suppressionRequirement) ? raw.suppressionRequirement : "any";
  for (const key of ["slotText", "prefix", "suffix", "grantUuids", "linkedText", "linkedPrefix", "linkedSuffix", "linkedGrantUuids", "partnerUuids", "suppressionUuids"]) {
    raw[key] = String(raw[key] ?? "");
  }
  raw.linkedModifiers = normalizeModifierRules(raw.linkedModifiers);

  raw.progression ??= {};
  raw.progression.enabled = Boolean(raw.progression.enabled);
  raw.progression.ap = Math.max(0, Math.floor(Number(raw.progression.ap ?? 0) || 0));
  raw.progression.maxLevel = clampLevel(raw.progression.maxLevel ?? 5);
  raw.progression.masteryBehavior = ["none", "notify", "chat", "duplicate"].includes(raw.progression.masteryBehavior)
    ? raw.progression.masteryBehavior
    : "none";
  raw.progression.masteredHandled = Boolean(raw.progression.masteredHandled);
  raw.progression.levels = normalizeLevelProfiles(raw.progression.levels, raw.progression.maxLevel);

  delete raw.partnerName;
  delete raw.suppressionName;
  return raw;
}

function getMateria(item) {
  return normalizeMateriaData(item?.getFlag(MODULE_ID, "materia") ?? {});
}

function getMateriaFromData(data) {
  return normalizeMateriaData(foundry.utils.getProperty(data ?? {}, `flags.${MODULE_ID}.materia`) ?? {});
}

function normalizeLinks(links, slotCount) {
  const normalized = [];
  const seen = new Set();
  const source = Array.isArray(links) ? links : [];

  for (const candidate of source) {
    if (!Array.isArray(candidate) || candidate.length < 2) continue;
    let a = Number.parseInt(candidate[0], 10);
    let b = Number.parseInt(candidate[1], 10);
    if (!Number.isInteger(a) || !Number.isInteger(b) || a === b) continue;
    if (a > b) [a, b] = [b, a];
    if (a < 0 || b >= slotCount) continue;

    const key = `${a}:${b}`;
    if (seen.has(key)) continue;
    seen.add(key);
    normalized.push([a, b]);
  }

  return normalized.sort((left, right) => (left[0] - right[0]) || (left[1] - right[1]));
}

function normalizeSlotRules(rules, slotCount) {
  const source = Array.isArray(rules) ? rules : [];
  return Array.from({ length: slotCount }, (_, index) => {
    const rule = foundry.utils.mergeObject(clone(DEFAULT_SLOT_RULE), clone(source[index] ?? {}), {
      inplace: false,
      recursive: true
    });
    rule.category = ["any", ...CATEGORY_VALUES].includes(rule.category) ? rule.category : "any";
    rule.uuids = String(rule.uuids ?? "");
    return rule;
  });
}

function getRawHost(item) {
  return clone(item?.getFlag(MODULE_ID, "host") ?? {});
}

function getHost(item) {
  const raw = foundry.utils.mergeObject(clone(DEFAULT_HOST), getRawHost(item), {
    inplace: false,
    recursive: true
  });
  raw.enabled = Boolean(raw.enabled);
  raw.slotCount = clampSlots(raw.slotCount);
  raw.slots = Array.from({ length: raw.slotCount }, (_, index) => raw.slots?.[index] ?? null);
  raw.links = normalizeLinks(raw.links, raw.slotCount);
  raw.growthMode = ["none", "normal", "double", "triple", "custom"].includes(raw.growthMode) ? raw.growthMode : "normal";
  raw.customGrowth = Math.max(0, Number(raw.customGrowth ?? 1) || 0);
  raw.appearance = ["cards", "sockets"].includes(raw.appearance) ? raw.appearance : "cards";
  raw.orientation = ["vertical", "horizontal", "wrap"].includes(raw.orientation) ? raw.orientation : "vertical";
  raw.allowedCategories = Array.isArray(raw.allowedCategories)
    ? [...new Set(raw.allowedCategories.filter(category => CATEGORY_VALUES.includes(category)))]
    : [];
  raw.allowedUuids = String(raw.allowedUuids ?? "");
  raw.requireEquipped = Boolean(raw.requireEquipped);
  raw.requireAttuned = Boolean(raw.requireAttuned);
  raw.minimumRarity = ["any", ...RARITY_ORDER].includes(raw.minimumRarity) ? raw.minimumRarity : "any";
  raw.requiredProperties = String(raw.requiredProperties ?? "");
  raw.slotRules = normalizeSlotRules(raw.slotRules, raw.slotCount);
  raw.statuses = Array.isArray(raw.statuses) ? raw.statuses.slice(0, raw.slotCount) : [];
  return raw;
}

function linkedPartnerIndices(host, slotIndex) {
  const partners = [];
  for (const pair of host.links ?? []) {
    if (pair[0] === slotIndex) partners.push(pair[1]);
    else if (pair[1] === slotIndex) partners.push(pair[0]);
  }
  return [...new Set(partners)].sort((a, b) => a - b);
}

function linkedGroupIndices(host, slotIndex) {
  const direct = linkedPartnerIndices(host, slotIndex);
  if (!direct.length) return [];

  const visited = new Set([slotIndex]);
  const queue = [slotIndex];
  while (queue.length) {
    const current = queue.shift();
    for (const partner of linkedPartnerIndices(host, current)) {
      if (visited.has(partner)) continue;
      visited.add(partner);
      queue.push(partner);
    }
  }
  visited.delete(slotIndex);
  return [...visited].sort((a, b) => a - b);
}

function isExactLink(host, a, b) {
  const low = Math.min(a, b);
  const high = Math.max(a, b);
  return (host.links ?? []).some(pair => pair[0] === low && pair[1] === high);
}

function isSlotLinked(host, slotIndex) {
  return linkedPartnerIndices(host, slotIndex).length > 0;
}

function parseUuidList(value) {
  return [...new Set(
    String(value ?? "")
      .split(",")
      .map(uuid => uuid.trim())
      .filter(Boolean)
  )];
}

function entryUuid(entry) {
  return String(entry?.item?.uuid ?? entry?.slot?.sourceUuid ?? entry?.slot?.uuid ?? "").trim();
}

function exactUuidRequirementMatches(csv, entry) {
  const uuids = parseUuidList(csv);
  if (!uuids.length) return true;
  const uuid = entryUuid(entry);
  return Boolean(uuid) && uuids.includes(uuid);
}

function currentMateriaLevel(materia) {
  const progression = materia?.progression;
  if (!progression?.enabled) return 1;
  const ap = Math.max(0, Number(progression.ap ?? 0) || 0);
  let level = 1;
  for (let i = 0; i < progression.levels.length; i++) {
    if (ap >= Number(progression.levels[i]?.threshold ?? 0)) level = i + 1;
  }
  return Math.min(progression.maxLevel, Math.max(1, level));
}

function currentLevelProfile(materia) {
  if (!materia?.progression?.enabled) return clone(DEFAULT_LEVEL_PROFILE);
  const level = currentMateriaLevel(materia);
  return materia?.progression?.levels?.[level - 1] ?? clone(DEFAULT_LEVEL_PROFILE);
}

function effectiveLinkedRules(materia) {
  const effective = clone(materia ?? {});
  const profile = currentLevelProfile(materia);
  if (profile.effectTiming && profile.effectTiming !== "inherit") effective.effectTiming = profile.effectTiming;
  if (profile.linkRequirement && profile.linkRequirement !== "inherit") effective.linkRequirement = profile.linkRequirement;
  if (String(profile.partnerUuids ?? "").trim()) effective.partnerUuids = profile.partnerUuids;
  if (profile.suppressionBehavior === "on") effective.suppressEffects = true;
  else if (profile.suppressionBehavior === "off") effective.suppressEffects = false;
  if (profile.suppressionScope && profile.suppressionScope !== "inherit") effective.suppressionScope = profile.suppressionScope;
  if (profile.suppressionRequirement && profile.suppressionRequirement !== "inherit") effective.suppressionRequirement = profile.suppressionRequirement;
  if (String(profile.suppressionUuids ?? "").trim()) effective.suppressionUuids = profile.suppressionUuids;
  return effective;
}

function materiaMastered(materia) {
  if (!materia?.progression?.enabled) return false;
  const max = clampLevel(materia.progression.maxLevel);
  const threshold = Number(materia.progression.levels?.[max - 1]?.threshold ?? Infinity);
  return Number(materia.progression.ap ?? 0) >= threshold;
}

function effectiveMateriaText(materia, key) {
  const base = String(materia?.[key] ?? "").trim();
  const levelValue = String(currentLevelProfile(materia)?.[key] ?? "").trim();
  return [base, levelValue].filter(Boolean).join(" — ");
}

function effectiveMateriaAffixes(materia, linked = false) {
  const profile = currentLevelProfile(materia);
  if (linked) return {
    prefix: [materia?.linkedPrefix, profile?.linkedPrefix].map(value => String(value ?? "").trim()).filter(Boolean).join(" "),
    suffix: [materia?.linkedSuffix, profile?.linkedSuffix].map(value => String(value ?? "").trim()).filter(Boolean).join(" ")
  };
  return {
    prefix: [materia?.prefix, profile?.prefix].map(value => String(value ?? "").trim()).filter(Boolean).join(" "),
    suffix: [materia?.suffix, profile?.suffix].map(value => String(value ?? "").trim()).filter(Boolean).join(" ")
  };
}

function effectMatchesCurrentLevel(effect, entry) {
  const csv = String(currentLevelProfile(entry?.materia)?.effectUuids ?? "").trim();
  const allowed = parseUuidList(csv);
  if (!allowed.length) return true;
  const effectId = String(effect?._id ?? effect?.id ?? "");
  const effectUuid = String(effect?.uuid ?? "");
  const sourceUuid = entryUuid(entry);
  const syntheticUuid = sourceUuid && effectId ? `${sourceUuid}.ActiveEffect.${effectId}` : "";
  return allowed.includes(effectId) || allowed.includes(effectUuid) || allowed.includes(syntheticUuid);
}

function rarityRank(value) {
  return RARITY_ORDER.indexOf(String(value ?? ""));
}

function itemPropertyValues(item) {
  const properties = foundry.utils.getProperty(item ?? {}, "system.properties") ?? item?.system?.properties;
  if (!properties) return [];
  if (properties instanceof Set) return [...properties].map(String);
  if (Array.isArray(properties)) return properties.map(String);
  if (typeof properties === "object") return Object.entries(properties).filter(([, enabled]) => Boolean(enabled)).map(([key]) => key);
  return [];
}

function hostActivationState(hostItem, host) {
  if (!host?.enabled) return { active: false, reasons: ["Materia is disabled on this equipment."] };
  const reasons = [];
  const equipped = Boolean(foundry.utils.getProperty(hostItem, "system.equipped") ?? hostItem?.system?.equipped);
  const attunedValue = foundry.utils.getProperty(hostItem, "system.attuned") ?? hostItem?.system?.attuned;
  const attunementValue = Number(foundry.utils.getProperty(hostItem, "system.attunement") ?? hostItem?.system?.attunement ?? 0);
  const attuned = Boolean(attunedValue) || attunementValue >= 2;
  if (host.requireEquipped && !equipped) reasons.push("Equipment is not equipped.");
  if (host.requireAttuned && !attuned) reasons.push("Equipment is not attuned.");

  if (host.minimumRarity !== "any") {
    const current = rarityRank(foundry.utils.getProperty(hostItem, "system.rarity") ?? hostItem?.system?.rarity);
    const required = rarityRank(host.minimumRarity);
    if (required >= 0 && current < required) reasons.push(`Equipment rarity is below ${host.minimumRarity}.`);
  }

  const requiredProperties = parseUuidList(host.requiredProperties);
  if (requiredProperties.length) {
    const actual = new Set(itemPropertyValues(hostItem));
    const missing = requiredProperties.filter(property => !actual.has(property));
    if (missing.length) reasons.push(`Missing required equipment properties: ${missing.join(", ")}.`);
  }
  return { active: reasons.length === 0, reasons };
}

function entryAllowedByHostRules(entry, host, slotIndex) {
  if (!entry?.materia) return { allowed: false, reason: "No Materia is present." };
  if (host.allowedCategories?.length && !host.allowedCategories.includes(entry.materia.category)) {
    return { allowed: false, reason: `Materia type ${CATEGORY_LABELS[entry.materia.category] ?? entry.materia.category} is not allowed on this equipment.` };
  }
  const hostUuids = parseUuidList(host.allowedUuids);
  if (hostUuids.length && !hostUuids.includes(entryUuid(entry))) {
    return { allowed: false, reason: "This Materia UUID is not allowed on this equipment." };
  }
  const rule = host.slotRules?.[slotIndex] ?? DEFAULT_SLOT_RULE;
  if (rule.category !== "any" && rule.category !== entry.materia.category) {
    return { allowed: false, reason: `This slot only accepts ${CATEGORY_LABELS[rule.category] ?? rule.category}.` };
  }
  const slotUuids = parseUuidList(rule.uuids);
  if (slotUuids.length && !slotUuids.includes(entryUuid(entry))) {
    return { allowed: false, reason: "This Materia UUID is not allowed in this slot." };
  }
  return { allowed: true, reason: "" };
}

function growthMultiplier(host) {
  if (host.growthMode === "none") return 0;
  if (host.growthMode === "double") return 2;
  if (host.growthMode === "triple") return 3;
  if (host.growthMode === "custom") return Math.max(0, Number(host.customGrowth ?? 1) || 0);
  return 1;
}

function categoryCss(category) {
  return CATEGORY_VALUES.includes(category) ? `gms-category-${category}` : "gms-category-other";
}

function partnerMeetsRequirement(materia, partnerEntry) {
  if (!partnerEntry?.materia || !partnerEntry?.item) return false;
  if (!exactUuidRequirementMatches(materia.partnerUuids, partnerEntry)) return false;

  const requirement = materia.linkRequirement ?? "any";
  if (requirement === "any") return true;
  if (requirement === "non-support") return partnerEntry.materia.category !== "support";
  return partnerEntry.materia.category === requirement;
}

function suppressionTargetMeetsRequirement(materia, targetEntry) {
  if (!targetEntry?.materia || !targetEntry?.item) return false;
  if (!exactUuidRequirementMatches(materia.suppressionUuids, targetEntry)) return false;

  const requirement = materia.suppressionRequirement ?? "any";
  if (requirement === "any") return true;
  if (requirement === "non-support") return targetEntry.materia.category !== "support";
  return targetEntry.materia.category === requirement;
}

function computeSuppressedSlots(host, resolvedSlots) {
  const suppressed = new Map();

  for (let suppressorIndex = 0; suppressorIndex < resolvedSlots.length; suppressorIndex++) {
    const suppressor = resolvedSlots[suppressorIndex];
    if (!suppressor?.materia) continue;
    const suppressorRules = effectiveLinkedRules(suppressor.materia);
    if (!suppressorRules.suppressEffects) continue;

    // Suppression is a Linked / Support behavior. It only turns on when this Materia
    // has at least one valid partner under its normal linked-partner rules.
    const linkState = getLinkState(host, resolvedSlots, suppressorIndex);
    if (!linkState.valid) continue;

    const candidates = suppressorRules.suppressionScope === "equipment"
      ? resolvedSlots.map((_entry, index) => index).filter(index => index !== suppressorIndex)
      : [...(linkState.partnerIndices ?? [])];

    for (const targetIndex of candidates) {
      if (targetIndex === suppressorIndex) continue;
      const target = resolvedSlots[targetIndex];
      if (!suppressionTargetMeetsRequirement(suppressorRules, target)) continue;
      const by = suppressed.get(targetIndex) ?? [];
      if (!by.includes(suppressorIndex)) by.push(suppressorIndex);
      suppressed.set(targetIndex, by);
    }
  }

  return suppressed;
}

function getLinkState(host, resolvedSlots, slotIndex) {
  const directPartnerIndices = linkedPartnerIndices(host, slotIndex);
  const partnerIndices = linkedGroupIndices(host, slotIndex);
  if (!partnerIndices.length) {
    return {
      linked: false,
      valid: false,
      directPartnerIndices: [],
      partnerIndices: [],
      validPartnerIndices: [],
      partnerIndex: null,
      partnerEntry: null,
      partnerEntries: [],
      reason: "Slot is not linked."
    };
  }

  const partnerEntries = partnerIndices
    .map(index => ({ index, entry: resolvedSlots[index] ?? null }))
    .filter(candidate => candidate.entry);

  const entry = resolvedSlots[slotIndex] ?? null;
  if (!entry?.materia) {
    return {
      linked: true,
      valid: false,
      directPartnerIndices,
      partnerIndices,
      validPartnerIndices: [],
      partnerIndex: partnerEntries[0]?.index ?? partnerIndices[0] ?? null,
      partnerEntry: partnerEntries[0]?.entry ?? null,
      partnerEntries,
      reason: "This slot is empty."
    };
  }

  if (!partnerEntries.length) {
    return {
      linked: true,
      valid: false,
      directPartnerIndices,
      partnerIndices,
      validPartnerIndices: [],
      partnerIndex: partnerIndices[0] ?? null,
      partnerEntry: null,
      partnerEntries: [],
      reason: "Every other slot in this linked group is empty."
    };
  }

  const linkRules = effectiveLinkedRules(entry.materia);
  const matches = partnerEntries.filter(candidate => partnerMeetsRequirement(linkRules, candidate.entry));
  const firstMatch = matches[0] ?? null;
  return {
    linked: true,
    valid: matches.length > 0,
    directPartnerIndices,
    partnerIndices,
    validPartnerIndices: matches.map(candidate => candidate.index),
    partnerIndex: firstMatch?.index ?? partnerEntries[0]?.index ?? null,
    partnerEntry: firstMatch?.entry ?? partnerEntries[0]?.entry ?? null,
    partnerEntries,
    reason: matches.length ? "" : "No Materia in this linked group meets this Materia's support requirement."
  };
}

function escapeHTML(value) {
  const div = document.createElement("div");
  div.textContent = String(value ?? "");
  return div.innerHTML;
}

function stripGeneratedDescription(html) {
  return String(html ?? "")
    .replace(/\s*<!-- GEOFEN_MATERIA_START -->[\s\S]*?<!-- GEOFEN_MATERIA_END -->\s*/g, "")
    .trim();
}

const VISIBILITY_CHOICES = Object.freeze({
  always: "Always",
  owner: "Owned Items Only",
  never: "Never"
});

function descriptionTerm(key, fallback) {
  try {
    const value = String(game.settings.get(MODULE_ID, key) ?? "").trim();
    return value || fallback;
  } catch (_error) {
    return fallback;
  }
}

function descriptionTerms() {
  return {
    materia: descriptionTerm("descriptionMateriaTerm", "Materia"),
    slot: descriptionTerm("descriptionSlotTerm", "Slot")
  };
}

async function refreshAllHostDescriptions() {
  if (!game?.ready) return;
  const jobs = [];
  for (const item of allHostItems()) {
    if (!canEdit(item) || !getHost(item).enabled) continue;
    jobs.push(rebuildHost(item, { render: false }));
  }
  await Promise.allSettled(jobs);
}

function registerVisibilitySettings() {
  game.settings.register(MODULE_ID, "migrationVersion", {
    name: "Materia Data Migration Version",
    scope: "world",
    config: false,
    type: String,
    default: "0"
  });

  const settings = [
    ["visibilityPlayer", "Player Visibility", "Choose when standard Players can see the Materia System on Item sheets.", "owner", VISIBILITY_CHOICES],
    ["visibilityTrusted", "Trusted Player Visibility", "Choose when Trusted Players can see the Materia System on Item sheets.", "owner", VISIBILITY_CHOICES],
    ["visibilityAssistant", "Assistant GM Visibility", "Choose when Assistant GMs can see the Materia System on Item sheets.", "always", VISIBILITY_CHOICES],
    ["visibilityGamemaster", "Game Master Visibility", "Game Masters always see the Materia System. This setting is intentionally locked.", "always", { always: "Always" }]
  ];

  for (const [key, name, hint, defaultValue, choices] of settings) {
    game.settings.register(MODULE_ID, key, {
      name,
      hint,
      scope: "world",
      config: true,
      type: String,
      choices,
      default: defaultValue,
      requiresReload: true
    });
  }

  game.settings.register(MODULE_ID, "descriptionMateriaTerm", {
    name: "Item Description Terminology — Materia",
    hint: "Changes only the Materia heading generated inside equipment item descriptions. It does not rename equipment, the module UI, prefixes, suffixes, or stored data.",
    scope: "world",
    config: true,
    type: String,
    default: "Materia",
    requiresReload: false,
    onChange: () => refreshAllHostDescriptions()
  });

  game.settings.register(MODULE_ID, "descriptionSlotTerm", {
    name: "Item Description Terminology — Slot",
    hint: "Changes only the Slot label generated inside equipment item descriptions. It does not rename equipment, the module UI, prefixes, suffixes, or stored data.",
    scope: "world",
    config: true,
    type: String,
    default: "Slot",
    requiresReload: false,
    onChange: () => refreshAllHostDescriptions()
  });

  game.settings.registerMenu(MODULE_ID, "materiaLibrary", {
    name: "Materia Library",
    label: "Open Materia Library",
    hint: "Create, duplicate, edit, import, export, and copy UUIDs for world-level Materia definitions.",
    icon: "fa-solid fa-gem",
    type: MateriaLibraryApp,
    restricted: true
  });

  game.settings.registerMenu(MODULE_ID, "materiaManager", {
    name: "Materia Manager & Recovery",
    label: "Open Materia Manager",
    hint: "Award AP, inspect installed Materia, rebuild equipment, diagnose broken references, and recover stored Materia.",
    icon: "fa-solid fa-screwdriver-wrench",
    type: MateriaManagerApp,
    restricted: true
  });
}

function visibilitySettingKey(user = game.user) {
  const roles = globalThis.CONST?.USER_ROLES ?? {};
  const role = Number(user?.role ?? roles.PLAYER ?? 1);
  if (role === Number(roles.GAMEMASTER ?? 4)) return "visibilityGamemaster";
  if (role === Number(roles.ASSISTANT ?? 3)) return "visibilityAssistant";
  if (role === Number(roles.TRUSTED ?? 2)) return "visibilityTrusted";
  return "visibilityPlayer";
}

function visibilityMode(user = game.user) {
  if (visibilitySettingKey(user) === "visibilityGamemaster") return "always";
  try {
    return game.settings.get(MODULE_ID, visibilitySettingKey(user)) ?? "owner";
  } catch (_error) {
    return "owner";
  }
}

function canViewMateriaPanel(item, user = game.user) {
  const mode = visibilityMode(user);
  if (mode === "never") return false;
  if (mode === "always") return true;
  return Boolean(item?.testUserPermission?.(user, "OWNER") ?? item?.isOwner);
}

function canEdit(item) {
  return Boolean(item?.isOwner ?? item?.testUserPermission?.(game.user, "OWNER"));
}

function isItemDocument(document) {
  return document?.documentName === "Item";
}

function isSupportedHost(item) {
  return isItemDocument(item) && HOST_TYPES.has(item.type) && item.getFlag?.(MODULE_ID, "generatedGrant") !== true;
}

function materiaAllowedOn(materia, host) {
  if (materia.allowed === "both") return true;
  return materia.allowed === host.type;
}

function isStoredSlot(slot) {
  return Boolean(slot?.itemData && typeof slot.itemData === "object");
}

function slotReferencesUuid(slot, uuid) {
  if (!slot || !uuid) return false;
  return slot.uuid === uuid || slot.sourceUuid === uuid;
}

function slotDisplay(slot) {
  if (!slot?.uuid && !isStoredSlot(slot)) return { name: "Empty", img: "icons/svg/item-bag.svg", uuid: null };
  return {
    name: slot.name || slot.itemData?.name || slot.uuid || "Stored Materia",
    img: slot.img || slot.itemData?.img || "icons/svg/item-bag.svg",
    uuid: slot.uuid ?? slot.sourceUuid ?? null
  };
}

function makeStoredSlot(source) {
  const data = source.toObject();
  delete data._stats;
  foundry.utils.setProperty(data, "system.quantity", 1);
  return {
    storageId: foundry.utils.randomID?.() ?? globalThis.crypto?.randomUUID?.() ?? `${Date.now()}-${Math.random()}`,
    sourceUuid: source.uuid,
    sourceItemId: source.id,
    sourceActorUuid: source.actor?.uuid ?? null,
    name: source.name,
    img: source.img,
    itemData: data
  };
}

async function consumeInventoryMateria(source) {
  const actor = source.actor;
  if (!actor) return;
  const quantity = Math.max(1, Number(foundry.utils.getProperty(source, "system.quantity") ?? 1));
  if (quantity > 1) {
    await source.update({ "system.quantity": quantity - 1 }, { [INTERNAL_OPTION]: { internal: true, inventoryTransfer: true } });
  } else {
    await source.delete({ [INTERNAL_OPTION]: { internal: true, inventoryTransfer: true } });
  }
}

async function restoreStoredMateria(hostItem, slot, { quiet = false } = {}) {
  if (!isStoredSlot(slot)) return true;
  const actor = hostItem.actor ?? (hostItem.parent?.documentName === "Actor" ? hostItem.parent : null);
  if (!actor) {
    if (!quiet) notify("This stored Materia cannot be returned because the equipment is not owned by an Actor.", "error");
    return false;
  }

  const existing = slot.sourceItemId ? actor.items?.get?.(slot.sourceItemId) : null;
  const storedMateria = getMateriaFromData(slot.itemData);
  if (existing && getMateria(existing).enabled) {
    const existingMateria = getMateria(existing);
    // Stacked Materia can merge back only when their complete Materia state still matches.
    // Once one unit gains AP or otherwise diverges while slotted, it is restored as its own
    // Item so per-Materia progression is not destroyed by a quantity merge.
    if (JSON.stringify(existingMateria) === JSON.stringify(storedMateria)) {
      const quantity = Math.max(0, Number(foundry.utils.getProperty(existing, "system.quantity") ?? 1));
      await existing.update({ "system.quantity": quantity + 1 }, { [INTERNAL_OPTION]: { internal: true, inventoryTransfer: true } });
      return true;
    }
  }

  const data = clone(slot.itemData);
  delete data._stats;
  foundry.utils.setProperty(data, "system.quantity", 1);
  if (slot.sourceItemId && !actor.items?.get?.(slot.sourceItemId)) data._id = slot.sourceItemId;
  else delete data._id;

  let created = null;
  try {
    created = await actor.createEmbeddedDocuments("Item", [data], {
      keepId: Boolean(data._id),
      [INTERNAL_OPTION]: { internal: true, inventoryTransfer: true }
    });
  } catch (error) {
    // If an ID collision or implementation detail prevents ID preservation, fall back
    // to a fresh embedded Item ID rather than leaving the Materia trapped in the slot.
    warn(`Could not restore Materia with its original Item ID; retrying with a new ID.`, error);
    delete data._id;
    created = await actor.createEmbeddedDocuments("Item", [data], { [INTERNAL_OPTION]: { internal: true, inventoryTransfer: true } });
  }

  if (!created?.length) {
    if (!quiet) notify(`Could not return ${slot.name ?? "Materia"} to ${actor.name}'s inventory.`, "error");
    return false;
  }
  return true;
}

function setMateriaOnItemData(itemData, materia) {
  foundry.utils.setProperty(itemData, `flags.${MODULE_ID}.materia`, materia);
  return itemData;
}

async function handleMastery(hostItem, slot, materia) {
  if (!materiaMastered(materia) || materia.progression.masteredHandled) return false;
  materia.progression.masteredHandled = true;
  const behavior = materia.progression.masteryBehavior;
  const actor = hostItem.actor ?? (hostItem.parent?.documentName === "Actor" ? hostItem.parent : null);
  const name = slot.name ?? slot.itemData?.name ?? "Materia";

  if (behavior === "notify") {
    notify(`${name} has been mastered${actor ? ` by ${actor.name}` : ""}.`);
  } else if (behavior === "chat") {
    try {
      await ChatMessage.create({
        speaker: actor ? ChatMessage.getSpeaker({ actor }) : undefined,
        content: `<p><strong>${escapeHTML(name)}</strong> has been mastered${actor ? ` by ${escapeHTML(actor.name)}` : ""}.</p>`
      });
    } catch (error) {
      warn("Could not post Materia mastery chat message", error);
    }
  } else if (behavior === "duplicate" && actor && slot.itemData) {
    const duplicate = clone(slot.itemData);
    delete duplicate._id;
    delete duplicate._stats;
    foundry.utils.setProperty(duplicate, "system.quantity", 1);
    const duplicateMateria = getMateriaFromData(duplicate);
    duplicateMateria.progression.ap = 0;
    duplicateMateria.progression.masteredHandled = false;
    setMateriaOnItemData(duplicate, duplicateMateria);
    try {
      await actor.createEmbeddedDocuments("Item", [duplicate], { [INTERNAL_OPTION]: { internal: true, masteryDuplicate: true } });
      notify(`${name} was mastered and created a new level 1 copy in ${actor.name}'s inventory.`);
    } catch (error) {
      warn("Could not create mastered Materia duplicate", error);
      notify(`${name} was mastered, but the new copy could not be created.`, "error");
    }
  }
  return true;
}

async function awardApToStoredSlot(hostItem, host, slotIndex, apAmount) {
  const slot = host.slots?.[slotIndex];
  if (!isStoredSlot(slot)) return { changed: false, skipped: "template" };
  const materia = getMateriaFromData(slot.itemData);
  if (!materia.enabled || !materia.progression.enabled) return { changed: false, skipped: "disabled" };

  const amount = Math.max(0, Math.floor(Number(apAmount) || 0));
  if (!amount) return { changed: false, skipped: "zero" };
  const previousLevel = currentMateriaLevel(materia);
  const wasMastered = materiaMastered(materia);
  if (!wasMastered) materia.progression.masteredHandled = false;
  materia.progression.ap += amount;
  await handleMastery(hostItem, slot, materia);
  setMateriaOnItemData(slot.itemData, materia);
  slot.name = slot.itemData.name ?? slot.name;
  slot.img = slot.itemData.img ?? slot.img;
  host.slots[slotIndex] = slot;
  return {
    changed: true,
    amount,
    previousLevel,
    level: currentMateriaLevel(materia),
    mastered: materiaMastered(materia),
    name: slot.name ?? "Materia"
  };
}

async function awardApToActor(actor, baseAp) {
  if (!actor) return { actor: null, awarded: 0, materia: 0, hosts: 0, skippedTemplates: 0 };
  const base = Math.max(0, Math.floor(Number(baseAp) || 0));
  const summary = { actor: actor.name, awarded: 0, materia: 0, hosts: 0, skippedTemplates: 0 };
  if (!base) return summary;

  for (const hostItem of actor.items?.filter?.(isSupportedHost) ?? []) {
    const host = getHost(hostItem);
    if (!host.enabled) continue;
    const multiplier = growthMultiplier(host);
    const award = Math.floor(base * multiplier);
    if (award <= 0) continue;
    let touched = false;
    for (let i = 0; i < host.slots.length; i++) {
      const result = await awardApToStoredSlot(hostItem, host, i, award);
      if (result.skipped === "template" && host.slots[i]) summary.skippedTemplates++;
      if (!result.changed) continue;
      touched = true;
      summary.materia++;
      summary.awarded += result.amount;
    }
    if (!touched) continue;
    summary.hosts++;
    await hostItem.setFlag(MODULE_ID, "host", host);
    await rebuildHost(hostItem, { render: false });
    refreshVisiblePanels(hostItem);
  }
  return summary;
}

async function awardApToAllActors(baseAp) {
  const summaries = [];
  for (const actor of game.actors ?? []) summaries.push(await awardApToActor(actor, baseAp));
  return summaries;
}

function generatedGrantedItems(actor, hostUuid = null) {
  if (!actor) return [];
  return actor.items?.filter?.(item => {
    if (item.getFlag?.(MODULE_ID, "generatedGrant") !== true) return false;
    return !hostUuid || item.getFlag?.(MODULE_ID, "sourceHostUuid") === hostUuid;
  }) ?? [];
}

async function deleteGeneratedGrants(actor, hostUuid) {
  const ids = generatedGrantedItems(actor, hostUuid).map(item => item.id);
  if (!ids.length) return;
  await actor.deleteEmbeddedDocuments("Item", ids, { [INTERNAL_OPTION]: { internal: true, generatedGrant: true } });
}

function grantUuidsForEntry(entry, linkState) {
  if (!entry?.materia) return [];
  const values = [entry.materia.grantUuids, currentLevelProfile(entry.materia)?.grantUuids];
  if (linkState?.valid) values.push(entry.materia.linkedGrantUuids);
  return [...new Set(values.flatMap(parseUuidList))];
}

async function syncGrantedItems(hostItem, host, resolvedSlots, hostActive = true) {
  const actor = hostItem.actor ?? (hostItem.parent?.documentName === "Actor" ? hostItem.parent : null);
  if (!actor) return;
  await deleteGeneratedGrants(actor, hostItem.uuid);
  if (!hostActive) return;

  const creations = [];
  for (let i = 0; i < resolvedSlots.length; i++) {
    const entry = resolvedSlots[i];
    if (!entry?.materia) continue;
    const ruleState = entryAllowedByHostRules(entry, host, i);
    if (!ruleState.allowed) continue;
    const linkState = getLinkState(host, resolvedSlots, i);
    if (effectiveLinkedRules(entry.materia).effectTiming === "linked" && !linkState.valid) continue;
    const uuids = grantUuidsForEntry(entry, linkState);
    for (const uuid of uuids) {
      let source = null;
      try { source = await fromUuid(uuid); } catch (error) { warn(`Could not resolve granted Item UUID ${uuid}`, error); }
      if (!isItemDocument(source)) continue;
      const data = source.toObject();
      delete data._id;
      delete data._stats;
      data.flags ??= {};
      data.flags[MODULE_ID] = {
        ...(data.flags[MODULE_ID] ?? {}),
        generatedGrant: true,
        sourceHostUuid: hostItem.uuid,
        sourceMateriaUuid: entryUuid(entry),
        sourceGrantUuid: uuid,
        sourceSlot: i
      };
      creations.push(data);
    }
  }
  if (creations.length) {
    await actor.createEmbeddedDocuments("Item", creations, { [INTERNAL_OPTION]: { internal: true, generatedGrant: true } });
  }
}

function prepareLinkedModifierEffect(entry, hostItem, linkState, slotIndex) {
  if (!entry?.materia || !linkState?.valid) return null;
  const rules = normalizeModifierRules(entry.materia.linkedModifiers);
  if (!rules.length) return null;
  const changes = rules.filter(rule => rule.path).map(rule => ({
    key: rule.path,
    mode: EFFECT_MODES[rule.mode] ?? EFFECT_MODES.override,
    value: rule.value,
    priority: 20
  }));
  if (!changes.length) return null;
  return {
    name: `${entry.item.name} — Linked Modifier`,
    img: entry.item.img,
    type: "enchantment",
    transfer: false,
    origin: entryUuid(entry),
    disabled: false,
    changes,
    system: { applicableType: "Item", isApplied: true },
    flags: {
      [MODULE_ID]: {
        generated: true,
        generatedModifier: true,
        sourceMateriaUuid: entryUuid(entry),
        sourceHostUuid: hostItem.uuid,
        sourceSlot: slotIndex,
        linkedPartnerSlots: [...(linkState.validPartnerIndices ?? [])]
      }
    }
  };
}

function allHostItems() {
  const items = [];
  for (const item of game.items ?? []) if (isSupportedHost(item)) items.push(item);
  for (const actor of game.actors ?? []) {
    for (const item of actor.items ?? []) if (isSupportedHost(item)) items.push(item);
  }
  return items;
}

function isAlreadySlotted(hostItem, materiaUuid, targetIndex = -1) {
  if (!materiaUuid) return false;
  const actor = hostItem.actor;
  const hosts = actor ? actor.items.filter(isSupportedHost) : [hostItem];
  for (const candidate of hosts) {
    const host = getHost(candidate);
    if (!host.enabled) continue;
    for (let i = 0; i < host.slots.length; i++) {
      if (candidate.id === hostItem.id && i === targetIndex) continue;
      if (host.slots[i]?.uuid === materiaUuid) return candidate;
    }
  }
  return false;
}

function generatedEffects(item) {
  return item.effects?.filter(effect => effect.getFlag(MODULE_ID, "generated") === true) ?? [];
}

async function deleteGeneratedEffects(item) {
  const ids = generatedEffects(item).map(effect => effect.id);
  if (!ids.length) return;
  await item.deleteEmbeddedDocuments("ActiveEffect", ids, { [INTERNAL_OPTION]: { internal: true } });
}

function buildHostStatuses(hostItem, host, resolvedSlots, suppressedSlots, activationState) {
  return Array.from({ length: host.slotCount }, (_, index) => {
    const entry = resolvedSlots[index];
    if (!entry?.materia) return {
      empty: true,
      active: false,
      name: "Empty",
      category: null,
      level: null,
      ap: null,
      mastered: false,
      linked: isSlotLinked(host, index),
      linkValid: false,
      suppressedBy: [],
      reason: "Empty slot."
    };
    const link = getLinkState(host, resolvedSlots, index);
    const ruleState = entryAllowedByHostRules(entry, host, index);
    const suppressedBy = suppressedSlots.get(index) ?? [];
    const reasons = [];
    if (!activationState.active) reasons.push(...activationState.reasons);
    if (!ruleState.allowed) reasons.push(ruleState.reason);
    const linkedRules = effectiveLinkedRules(entry.materia);
    if (linkedRules.effectTiming === "linked" && !link.valid) reasons.push(link.reason || "Linked requirement is not met.");
    if (suppressedBy.length) reasons.push(`Active Effects suppressed by Slot${suppressedBy.length === 1 ? "" : "s"} ${suppressedBy.map(i => i + 1).join(", ")}.`);
    return {
      empty: false,
      active: activationState.active && ruleState.allowed && (linkedRules.effectTiming !== "linked" || link.valid),
      name: entry.item.name,
      category: entry.materia.category,
      level: currentMateriaLevel(entry.materia),
      ap: entry.materia.progression?.enabled ? entry.materia.progression.ap : null,
      mastered: materiaMastered(entry.materia),
      linked: link.linked,
      linkValid: link.valid,
      suppressedBy,
      reason: reasons.join(" ")
    };
  });
}

function generatedDescription(host, resolvedSlots) {
  if (!host.enabled || host.slotCount < 1) return "";
  const lines = [];
  const suppressedSlots = computeSuppressedSlots(host, resolvedSlots);
  const terms = descriptionTerms();
  const slotLabel = escapeHTML(terms.slot);
  const materiaLabel = escapeHTML(terms.materia);
  const slotRef = index => `${slotLabel} ${index + 1}`;

  for (let i = 0; i < host.slotCount; i++) {
    const entry = resolvedSlots[i];
    const link = getLinkState(host, resolvedSlots, i);
    const status = host.statuses?.[i] ?? null;
    const groupLabel = link.partnerIndices?.length
      ? link.partnerIndices.map(index => slotRef(index)).join(", ")
      : "";

    if (!entry?.materia) {
      const linkText = link.linked
        ? ` <em class="gms-description-link">(Linked group: ${groupLabel})</em>`
        : "";
      lines.push(`<p><strong>${slotRef(i)}:</strong> Empty${linkText}</p>`);
      continue;
    }

    const details = [];
    const text = effectiveMateriaText(entry.materia, "slotText");
    if (text) details.push(escapeHTML(text));

    const linkedText = effectiveMateriaText(entry.materia, "linkedText");
    if (link.valid && linkedText) details.push(escapeHTML(linkedText));

    if (entry.materia.progression?.enabled) {
      const level = currentMateriaLevel(entry.materia);
      const mastered = materiaMastered(entry.materia);
      details.push(`Level ${level}/${entry.materia.progression.maxLevel}${mastered ? " — MASTERED" : ""}; AP ${entry.materia.progression.ap}`);
    }

    const suppressors = suppressedSlots.get(i) ?? [];
    if (suppressors.length) details.push(`Active Effects suppressed by ${suppressors.map(index => slotRef(index)).join(", ")}`);
    if (status?.reason && !status.active && !suppressors.length) details.push(`Inactive: ${escapeHTML(status.reason)}`);

    const detailText = details.length ? ` — ${details.join(" — ")}` : "";

    let linkText = "";
    if (link.linked) {
      const matchingNames = (link.validPartnerIndices ?? []).map(index => {
        const partner = resolvedSlots[index];
        return partner ? `${slotRef(index)}: ${escapeHTML(partner.item.name)}` : slotRef(index);
      });
      if (link.valid) {
        linkText = ` <em class="gms-description-link">(Linked group: ${groupLabel}; valid partner${matchingNames.length === 1 ? "" : "s"}: ${matchingNames.join(", ")})</em>`;
      } else {
        linkText = ` <em class="gms-description-link gms-link-inactive">(Linked group: ${groupLabel}; support inactive)</em>`;
      }
    }

    lines.push(`<p><strong>${slotRef(i)}:</strong> ${escapeHTML(entry.item.name)}${detailText}${linkText}</p>`);
  }

  return `
<!-- GEOFEN_MATERIA_START -->
<section class="geofen-materia-description" data-geofen-materia-generated="true">
<h3>${materiaLabel}</h3>
${lines.join("\n")}
</section>
<!-- GEOFEN_MATERIA_END -->`;
}

function generatedName(host, resolvedSlots) {
  const baseName = String(host.baseName ?? "").trim();
  const prefixes = [];
  const suffixes = [];

  for (let i = 0; i < resolvedSlots.length; i++) {
    const entry = resolvedSlots[i];
    if (!entry?.materia) continue;
    const ruleState = entryAllowedByHostRules(entry, host, i);
    if (!ruleState.allowed) continue;

    const normal = effectiveMateriaAffixes(entry.materia, false);
    if (normal.prefix) prefixes.push(normal.prefix);
    if (normal.suffix) suffixes.push(normal.suffix);

    const link = getLinkState(host, resolvedSlots, i);
    if (link.valid) {
      const linked = effectiveMateriaAffixes(entry.materia, true);
      if (linked.prefix) prefixes.push(linked.prefix);
      if (linked.suffix) suffixes.push(linked.suffix);
    }
  }

  return [prefixes.join(" "), baseName, suffixes.length ? suffixes.join(" ") : ""]
    .filter(Boolean)
    .join(" ")
    .replace(/\s+/g, " ")
    .trim();
}

function effectFlag(effect, scope, key) {
  if (typeof effect?.getFlag === "function") return effect.getFlag(scope, key);
  return foundry.utils.getProperty(effect ?? {}, `flags.${scope}.${key}`);
}

function effectObject(effect) {
  return typeof effect?.toObject === "function" ? effect.toObject() : clone(effect ?? {});
}

function prepareEffectClone(effect, sourceMateria, hostItem, linkState = null) {
  if (effectFlag(effect, MODULE_ID, "generated")) return null;
  if (effect?.disabled) return null;

  const data = effectObject(effect);
  delete data._id;
  delete data._stats;

  data.flags ??= {};
  data.flags[MODULE_ID] = {
    generated: true,
    sourceMateriaUuid: sourceMateria.uuid,
    sourceHostUuid: hostItem.uuid,
    linkedPartnerUuid: linkState?.valid ? linkState.partnerEntry?.item?.uuid ?? null : null,
    linkedPartnerSlot: linkState?.valid ? linkState.partnerIndex : null,
    linkedPartnerUuids: linkState?.valid
      ? (linkState.validPartnerIndices ?? []).map(index => linkState.partnerEntries?.find(candidate => candidate.index === index)?.entry?.item?.uuid).filter(Boolean)
      : [],
    linkedPartnerSlots: linkState?.valid ? [...(linkState.validPartnerIndices ?? [])] : []
  };
  data.origin = sourceMateria.uuid;

  const applicableType = effect.system?.applicableType ?? (effect.type === "enchantment" ? "Item" : "Actor");
  if (effect.type === "enchantment" || applicableType === "Item") {
    data.type = "enchantment";
    data.transfer = false;
    data.system ??= {};
    data.system.applicableType = "Item";
    if ("isApplied" in data.system) data.system.isApplied = true;
  } else {
    data.transfer = true;
    data.system ??= {};
    data.system.applicableType = "Actor";
  }

  return data;
}

async function resolveSlots(hostItem, host) {
  const resolved = [];
  let changedSnapshots = false;

  for (let i = 0; i < host.slotCount; i++) {
    const slot = host.slots[i];
    if (!slot?.uuid && !isStoredSlot(slot)) {
      resolved.push(null);
      continue;
    }

    if (isStoredSlot(slot)) {
      const data = clone(slot.itemData);
      const materia = getMateriaFromData(data);
      if (!materia.enabled || !materiaAllowedOn(materia, hostItem)) {
        resolved.push(null);
        continue;
      }

      const storedItem = {
        documentName: "Item",
        name: data.name ?? slot.name ?? "Stored Materia",
        img: data.img ?? slot.img ?? "icons/svg/item-bag.svg",
        uuid: slot.sourceUuid ?? `StoredMateria.${slot.storageId ?? i}`,
        effects: Array.isArray(data.effects) ? data.effects : []
      };

      if (slot.name !== storedItem.name || slot.img !== storedItem.img) {
        slot.name = storedItem.name;
        slot.img = storedItem.img;
        changedSnapshots = true;
      }

      resolved.push({ item: storedItem, materia, stored: true, itemData: data, slot });
      continue;
    }

    let source = null;
    try {
      source = await fromUuid(slot.uuid);
    } catch (error) {
      warn(`Could not resolve Materia UUID ${slot.uuid}`, error);
    }

    if (!isItemDocument(source)) {
      resolved.push(null);
      continue;
    }

    const materia = getMateria(source);
    if (!materia.enabled || !materiaAllowedOn(materia, hostItem)) {
      resolved.push(null);
      continue;
    }

    if (slot.name !== source.name || slot.img !== source.img) {
      host.slots[i] = { uuid: source.uuid, name: source.name, img: source.img };
      changedSnapshots = true;
    }

    resolved.push({ item: source, materia, stored: false });
  }

  return { resolved, changedSnapshots };
}

async function rebuildHost(hostItem, { render = false } = {}) {
  if (!isSupportedHost(hostItem) || !canEdit(hostItem)) return;
  const host = getHost(hostItem);

  host.baseName ||= String(hostItem.name ?? "");
  host.baseDescription ||= stripGeneratedDescription(hostItem.system?.description?.value ?? "");

  await deleteGeneratedEffects(hostItem);
  if (hostItem.actor) await deleteGeneratedGrants(hostItem.actor, hostItem.uuid);

  if (!host.enabled) {
    host.statuses = [];
    const currentDescription = hostItem.system?.description?.value ?? "";
    const updates = {
      name: host.baseName || hostItem.name,
      "system.description.value": host.baseDescription || stripGeneratedDescription(currentDescription),
      [`flags.${MODULE_ID}.host`]: host
    };
    await hostItem.update(updates, { [INTERNAL_OPTION]: { internal: true } });
    if (render) await renderItemSheet(hostItem);
    return;
  }

  const { resolved } = await resolveSlots(hostItem, host);
  const activationState = hostActivationState(hostItem, host);
  const suppressedSlots = computeSuppressedSlots(host, resolved);
  host.statuses = buildHostStatuses(hostItem, host, resolved, suppressedSlots, activationState);
  const effectData = [];

  if (activationState.active) {
    for (let i = 0; i < resolved.length; i++) {
      const entry = resolved[i];
      if (!entry?.materia) continue;
      const ruleState = entryAllowedByHostRules(entry, host, i);
      if (!ruleState.allowed) continue;
      const linkState = getLinkState(host, resolved, i);
      const suppressed = suppressedSlots.has(i);

      const linkedRules = effectiveLinkedRules(entry.materia);
      if (entry.materia.copyEffects && !suppressed && (linkedRules.effectTiming !== "linked" || linkState.valid)) {
        for (const effect of entry.item.effects ?? []) {
          if (!effectMatchesCurrentLevel(effect, entry)) continue;
          const data = prepareEffectClone(effect, entry.item, hostItem, linkState);
          if (data) effectData.push(data);
        }
      }

      if (!suppressed) {
        const modifier = prepareLinkedModifierEffect(entry, hostItem, linkState, i);
        if (modifier) effectData.push(modifier);
      }
    }
  }

  const nextName = generatedName(host, resolved) || host.baseName || hostItem.name;
  const nextDescription = `${host.baseDescription}${generatedDescription(host, resolved)}`;

  await hostItem.update({
    name: nextName,
    "system.description.value": nextDescription,
    [`flags.${MODULE_ID}.host`]: host
  }, { [INTERNAL_OPTION]: { internal: true } });

  if (effectData.length) {
    await hostItem.createEmbeddedDocuments("ActiveEffect", effectData, { [INTERNAL_OPTION]: { internal: true } });
  }
  await syncGrantedItems(hostItem, host, resolved, activationState.active);

  if (render) await renderItemSheet(hostItem);
}

async function renderItemSheet(item) {
  const sheet = item?.sheet;
  if (!sheet?.render) return;
  try {
    await sheet.render(true);
  } catch (error) {
    warn(`Could not re-render sheet for ${item?.name ?? item?.uuid ?? "Item"}`, error);
  }
}

function refreshPanel(item, panel) {
  if (!panel?.isConnected) return null;
  const openSections = captureOpenSections(panel);
  const replacement = buildPanel(item, { openSections });
  panel.replaceWith(replacement);
  bindPanel(item, replacement);
  return replacement;
}

function refreshVisiblePanels(item, preferredPanel = null) {
  const refreshed = new Set();
  if (preferredPanel?.isConnected) {
    const replacement = refreshPanel(item, preferredPanel);
    if (replacement) refreshed.add(replacement);
  }

  for (const panel of document.querySelectorAll?.(".geofen-materia-panel") ?? []) {
    if (!panel.isConnected || panel.dataset.itemUuid !== item.uuid || refreshed.has(panel)) continue;
    refreshPanel(item, panel);
  }
}

async function refreshHostsReferencing(materiaUuid, { clearMissing = false } = {}) {
  const jobs = [];
  for (const item of allHostItems()) {
    if (!canEdit(item)) continue;
    const host = getHost(item);
    if (!host.enabled) continue;
    let touched = false;
    for (let i = 0; i < host.slots.length; i++) {
      if (host.slots[i]?.uuid !== materiaUuid) continue;
      touched = true;
      if (clearMissing) host.slots[i] = null;
    }
    if (!touched) continue;
    if (clearMissing) {
      await item.setFlag(MODULE_ID, "host", host);
    }
    jobs.push(rebuildHost(item, { render: false }).then(() => refreshVisiblePanels(item)));
  }
  await Promise.allSettled(jobs);
}

async function restoreSlotsForConfigurationChange(item, host, indices) {
  for (const index of indices) {
    const slot = host.slots[index];
    if (!slot) continue;
    if (isStoredSlot(slot)) {
      try {
        const restored = await restoreStoredMateria(item, slot);
        if (!restored) return false;
      } catch (error) {
        console.error(`${MODULE_ID} | Failed to return stored Materia before equipment configuration change`, error);
        notify(`Could not return ${slot.name ?? "Materia"} to inventory. Equipment settings were not changed.`, "error");
        return false;
      }
    }
    host.slots[index] = null;
  }
  return true;
}

async function saveHostConfiguration(item, panel) {
  const host = getHost(item);
  const enabled = Boolean(panel.querySelector('[data-field="host-enabled"]')?.checked);
  const slotCount = clampSlots(panel.querySelector('[data-field="slot-count"]')?.value ?? host.slotCount);

  if (!host.baseName) host.baseName = item.name;
  if (!host.baseDescription) host.baseDescription = stripGeneratedDescription(item.system?.description?.value ?? "");

  const slotsToRelease = [];
  if (!enabled) {
    for (let i = 0; i < host.slots.length; i++) if (host.slots[i]) slotsToRelease.push(i);
  } else if (slotCount < host.slotCount) {
    for (let i = slotCount; i < host.slotCount; i++) if (host.slots[i]) slotsToRelease.push(i);
  }

  if (slotsToRelease.length) {
    const released = await restoreSlotsForConfigurationChange(item, host, slotsToRelease);
    if (!released) return;
  }

  host.enabled = enabled;
  host.slotCount = slotCount;
  host.slots = Array.from({ length: slotCount }, (_, index) => enabled ? (host.slots[index] ?? null) : null);
  host.links = normalizeLinks(host.links, slotCount);
  host.growthMode = panel.querySelector('[data-field="host-growth-mode"]')?.value ?? host.growthMode;
  host.customGrowth = Math.max(0, Number(panel.querySelector('[data-field="host-custom-growth"]')?.value ?? host.customGrowth) || 0);
  host.appearance = panel.querySelector('[data-field="host-appearance"]')?.value === "sockets" ? "sockets" : "cards";
  host.orientation = ["vertical", "horizontal", "wrap"].includes(panel.querySelector('[data-field="host-orientation"]')?.value)
    ? panel.querySelector('[data-field="host-orientation"]').value
    : "vertical";
  host.allowedCategories = CATEGORY_VALUES.filter(category => panel.querySelector(`[data-field="host-allowed-category-${category}"]`)?.checked);
  host.allowedUuids = panel.querySelector('[data-field="host-allowed-uuids"]')?.value ?? "";
  host.requireEquipped = Boolean(panel.querySelector('[data-field="host-require-equipped"]')?.checked);
  host.requireAttuned = Boolean(panel.querySelector('[data-field="host-require-attuned"]')?.checked);
  host.minimumRarity = panel.querySelector('[data-field="host-min-rarity"]')?.value ?? "any";
  host.requiredProperties = panel.querySelector('[data-field="host-required-properties"]')?.value ?? "";
  host.slotRules = Array.from({ length: slotCount }, (_, index) => ({
    category: panel.querySelector(`[data-field="slot-rule-category-${index}"]`)?.value ?? host.slotRules?.[index]?.category ?? "any",
    uuids: panel.querySelector(`[data-field="slot-rule-uuids-${index}"]`)?.value ?? host.slotRules?.[index]?.uuids ?? ""
  }));

  await item.setFlag(MODULE_ID, "host", host);
  await rebuildHost(item, { render: false });
  refreshVisiblePanels(item, panel);
  notify(`Materia configuration saved for ${host.baseName || item.name}.`);
}

async function saveMateriaConfiguration(item, panel) {
  const materia = getMateria(item);
  materia.enabled = Boolean(panel.querySelector('[data-field="materia-enabled"]')?.checked);
  materia.category = panel.querySelector('[data-field="materia-category"]')?.value ?? "magic";
  materia.allowed = panel.querySelector('[data-field="materia-allowed"]')?.value ?? "both";
  materia.slotText = panel.querySelector('[data-field="materia-text"]')?.value ?? "";
  materia.prefix = panel.querySelector('[data-field="materia-prefix"]')?.value ?? "";
  materia.suffix = panel.querySelector('[data-field="materia-suffix"]')?.value ?? "";
  materia.copyEffects = Boolean(panel.querySelector('[data-field="materia-copy-effects"]')?.checked);
  materia.effectTiming = panel.querySelector('[data-field="materia-effect-timing"]')?.value === "linked" ? "linked" : "always";
  materia.grantUuids = panel.querySelector('[data-field="materia-grant-uuids"]')?.value ?? "";
  materia.linkRequirement = panel.querySelector('[data-field="materia-link-requirement"]')?.value ?? "any";
  materia.partnerUuids = panel.querySelector('[data-field="materia-partner-uuids"]')?.value ?? "";
  materia.linkedText = panel.querySelector('[data-field="materia-linked-text"]')?.value ?? "";
  materia.linkedPrefix = panel.querySelector('[data-field="materia-linked-prefix"]')?.value ?? "";
  materia.linkedSuffix = panel.querySelector('[data-field="materia-linked-suffix"]')?.value ?? "";
  materia.linkedGrantUuids = panel.querySelector('[data-field="materia-linked-grant-uuids"]')?.value ?? "";
  materia.suppressEffects = Boolean(panel.querySelector('[data-field="materia-suppress-effects"]')?.checked);
  materia.suppressionScope = panel.querySelector('[data-field="materia-suppression-scope"]')?.value === "equipment" ? "equipment" : "linked-group";
  materia.suppressionRequirement = panel.querySelector('[data-field="materia-suppression-requirement"]')?.value ?? "any";
  materia.suppressionUuids = panel.querySelector('[data-field="materia-suppression-uuids"]')?.value ?? "";
  materia.linkedModifiers = Array.from({ length: 8 }, (_, index) => ({
    path: panel.querySelector(`[data-field="modifier-path-${index}"]`)?.value ?? "",
    mode: panel.querySelector(`[data-field="modifier-mode-${index}"]`)?.value ?? "override",
    value: panel.querySelector(`[data-field="modifier-value-${index}"]`)?.value ?? ""
  })).filter(rule => rule.path || rule.value);

  materia.progression.enabled = Boolean(panel.querySelector('[data-field="progression-enabled"]')?.checked);
  materia.progression.ap = Math.max(0, Math.floor(Number(panel.querySelector('[data-field="progression-ap"]')?.value ?? materia.progression.ap) || 0));
  materia.progression.maxLevel = clampLevel(panel.querySelector('[data-field="progression-max-level"]')?.value ?? materia.progression.maxLevel);
  materia.progression.masteryBehavior = panel.querySelector('[data-field="progression-mastery"]')?.value ?? "none";
  const existingProfiles = normalizeLevelProfiles(materia.progression.levels, materia.progression.maxLevel);
  materia.progression.levels = Array.from({ length: materia.progression.maxLevel }, (_, index) => {
    const current = existingProfiles[index] ?? clone(DEFAULT_LEVEL_PROFILE);
    return {
      threshold: Math.max(0, Math.floor(Number(panel.querySelector(`[data-field="level-threshold-${index}"]`)?.value ?? current.threshold) || 0)),
      slotText: panel.querySelector(`[data-field="level-slot-text-${index}"]`)?.value ?? current.slotText,
      linkedText: panel.querySelector(`[data-field="level-linked-text-${index}"]`)?.value ?? current.linkedText,
      prefix: panel.querySelector(`[data-field="level-prefix-${index}"]`)?.value ?? current.prefix,
      suffix: panel.querySelector(`[data-field="level-suffix-${index}"]`)?.value ?? current.suffix,
      linkedPrefix: panel.querySelector(`[data-field="level-linked-prefix-${index}"]`)?.value ?? current.linkedPrefix,
      linkedSuffix: panel.querySelector(`[data-field="level-linked-suffix-${index}"]`)?.value ?? current.linkedSuffix,
      effectUuids: panel.querySelector(`[data-field="level-effect-uuids-${index}"]`)?.value ?? current.effectUuids,
      grantUuids: panel.querySelector(`[data-field="level-grant-uuids-${index}"]`)?.value ?? current.grantUuids,
      effectTiming: panel.querySelector(`[data-field="level-effect-timing-${index}"]`)?.value ?? current.effectTiming,
      linkRequirement: panel.querySelector(`[data-field="level-link-requirement-${index}"]`)?.value ?? current.linkRequirement,
      partnerUuids: panel.querySelector(`[data-field="level-partner-uuids-${index}"]`)?.value ?? current.partnerUuids,
      suppressionBehavior: panel.querySelector(`[data-field="level-suppression-behavior-${index}"]`)?.value ?? current.suppressionBehavior,
      suppressionScope: panel.querySelector(`[data-field="level-suppression-scope-${index}"]`)?.value ?? current.suppressionScope,
      suppressionRequirement: panel.querySelector(`[data-field="level-suppression-requirement-${index}"]`)?.value ?? current.suppressionRequirement,
      suppressionUuids: panel.querySelector(`[data-field="level-suppression-uuids-${index}"]`)?.value ?? current.suppressionUuids
    };
  });
  materia.progression = normalizeMateriaData({ progression: materia.progression }).progression;
  if (!materiaMastered(materia)) materia.progression.masteredHandled = false;

  await item.setFlag(MODULE_ID, "materia", materia);
  await refreshHostsReferencing(item.uuid);
  refreshVisiblePanels(item, panel);
  notify(`${item.name} Materia configuration saved.`);
}

async function removeSlot(item, slotIndex, panel) {
  const host = getHost(item);
  if (slotIndex < 0 || slotIndex >= host.slotCount) return;
  const slot = host.slots[slotIndex];
  if (!slot) return;

  if (isStoredSlot(slot)) {
    try {
      const restored = await restoreStoredMateria(item, slot);
      if (!restored) return;
    } catch (error) {
      console.error(`${MODULE_ID} | Failed to return slotted Materia to inventory`, error);
      return notify(`Could not return ${slot.name ?? "Materia"} to inventory. The slot was left unchanged.`, "error");
    }
  }

  host.slots[slotIndex] = null;
  await item.setFlag(MODULE_ID, "host", host);
  await rebuildHost(item, { render: false });
  refreshVisiblePanels(item, panel);
  notify(`${slot.name ?? "Materia"} removed from Slot ${slotIndex + 1}${isStoredSlot(slot) ? " and returned to inventory" : ""}.`);
}

async function toggleLink(item, firstIndex, secondIndex, panel) {
  const host = getHost(item);
  let a = Number(firstIndex);
  let b = Number(secondIndex);
  if (!Number.isInteger(a) || !Number.isInteger(b) || a === b) return;
  if (a > b) [a, b] = [b, a];
  if (!host.enabled || a < 0 || b >= host.slotCount) return;

  const wasLinked = isExactLink(host, a, b);
  if (wasLinked) {
    host.links = host.links.filter(pair => !(pair[0] === a && pair[1] === b));
  } else {
    host.links = normalizeLinks([...(host.links ?? []), [a, b]], host.slotCount);
  }

  await item.setFlag(MODULE_ID, "host", host);
  await rebuildHost(item, { render: false });
  refreshVisiblePanels(item, panel);
  notify(wasLinked
    ? `Direct link removed between Slots ${a + 1} and ${b + 1}.`
    : `Slots ${a + 1} and ${b + 1} are now linked.`);
}

function extractDropData(event) {
  const candidates = [
    event.dataTransfer?.getData("text/plain"),
    event.dataTransfer?.getData("application/json")
  ].filter(Boolean);

  for (const raw of candidates) {
    try {
      const data = JSON.parse(raw);
      if (data && typeof data === "object") return data;
    } catch (_error) {
      // Ignore non-JSON drag payloads.
    }
  }
  return null;
}

async function slotMateria(hostItem, slotIndex, event, panel) {
  event.preventDefault();
  event.stopPropagation();

  if (!canEdit(hostItem)) return;
  const host = getHost(hostItem);
  if (!host.enabled || slotIndex < 0 || slotIndex >= host.slotCount) return;
  if (host.slots[slotIndex]) {
    return notify(`Slot ${slotIndex + 1} already contains Materia. Remove it with the × button before inserting another.`, "warn");
  }

  const data = extractDropData(event);
  if (!data) return notify("That drop did not contain a Foundry Item.", "warn");

  let source = null;
  try {
    if (data.uuid) source = await fromUuid(data.uuid);
    else if (data.type === "Item" && data.data?._id) source = game.items.get(data.data._id);
  } catch (error) {
    warn("Failed to resolve dropped Item", error);
  }

  if (!isItemDocument(source)) return notify("Only Items can be slotted as Materia.", "warn");
  if (source === hostItem || (source.id === hostItem.id && source.actor && source.actor === hostItem.actor)) {
    return notify("Equipment cannot be slotted into itself.", "warn");
  }

  const materia = getMateria(source);
  if (!materia.enabled) return notify(`${source.name} is not configured as Materia.`, "warn");
  if (!materiaAllowedOn(materia, hostItem)) {
    return notify(`${source.name} is not allowed on ${hostItem.type} items.`, "warn");
  }

  const ruleCheck = entryAllowedByHostRules({ item: source, materia, slot: { sourceUuid: source.uuid, uuid: source.uuid } }, host, slotIndex);
  if (!ruleCheck.allowed) return notify(ruleCheck.reason, "warn");

  if (source.actor && hostItem.actor && source.actor !== hostItem.actor) {
    return notify("Materia must be in the same Actor inventory as the equipment before it can be slotted.", "warn");
  }
  if (source.actor && !hostItem.actor) {
    return notify("Actor-owned Materia cannot be moved into an unowned world Item. Put the equipment on the same Actor first.", "warn");
  }

  // Actor-owned Materia is physically transferred into the slot. The Item data is
  // stored on the host and one inventory quantity is consumed. Pressing × restores it.
  if (source.actor && hostItem.actor && source.actor === hostItem.actor) {
    const storedSlot = makeStoredSlot(source);
    host.slots[slotIndex] = storedSlot;
    await hostItem.setFlag(MODULE_ID, "host", host);

    try {
      await consumeInventoryMateria(source);
    } catch (error) {
      console.error(`${MODULE_ID} | Failed to remove slotted Materia from inventory`, error);
      host.slots[slotIndex] = null;
      await hostItem.setFlag(MODULE_ID, "host", host);
      return notify(`${source.name} could not be removed from inventory, so it was not slotted.`, "error");
    }

    await rebuildHost(hostItem, { render: false });
    refreshVisiblePanels(hostItem, panel);
    notify(`${storedSlot.name} moved from inventory into Slot ${slotIndex + 1}.`);
    return;
  }

  // World/Compendium Items behave as templates because they are not part of an Actor inventory.
  const duplicateHost = isAlreadySlotted(hostItem, source.uuid, slotIndex);
  if (duplicateHost) {
    return notify(`${source.name} is already slotted in ${duplicateHost.name}.`, "warn");
  }

  host.slots[slotIndex] = { uuid: source.uuid, name: source.name, img: source.img };
  await hostItem.setFlag(MODULE_ID, "host", host);
  await rebuildHost(hostItem, { render: false });
  refreshVisiblePanels(hostItem, panel);
  notify(`${source.name} slotted into Slot ${slotIndex + 1}.`);
}

function hostSection(item, host, editable, openSections = null) {
  if (!isSupportedHost(item)) return "";
  const disabled = editable ? "" : "disabled";
  const sectionOpen = isSectionOpen(openSections, "host");
  const linkLayoutOpen = isSectionOpen(openSections, "host-links");
  const growthOpen = isSectionOpen(openSections, "host-growth");
  const appearanceOpen = isSectionOpen(openSections, "host-appearance");
  const rulesOpen = isSectionOpen(openSections, "host-rules");
  const options = Array.from({ length: MAX_SLOTS + 1 }, (_, i) =>
    `<option value="${i}" ${host.slotCount === i ? "selected" : ""}>${i}</option>`
  ).join("");

  const growthOptions = [
    ["none", "None (0×)"], ["normal", "Normal (1×)"], ["double", "Double (2×)"], ["triple", "Triple (3×)"], ["custom", "Custom"]
  ].map(([value, label]) => `<option value="${value}" ${host.growthMode === value ? "selected" : ""}>${label}</option>`).join("");
  const appearanceOptions = [["cards", "Detailed Cards"], ["sockets", "Compact Sockets"]]
    .map(([value, label]) => `<option value="${value}" ${host.appearance === value ? "selected" : ""}>${label}</option>`).join("");
  const orientationOptions = [["vertical", "Vertical"], ["horizontal", "Horizontal"], ["wrap", "Wrap"]]
    .map(([value, label]) => `<option value="${value}" ${host.orientation === value ? "selected" : ""}>${label}</option>`).join("");
  const rarityOptions = [["any", "Any Rarity"], ...RARITY_ORDER.map(value => [value, value.replace(/([A-Z])/g, " $1").replace(/^./, c => c.toUpperCase())])]
    .map(([value, label]) => `<option value="${value}" ${host.minimumRarity === value ? "selected" : ""}>${label}</option>`).join("");
  const categoryRuleOptions = [["any", "Any Type"], ...CATEGORY_VALUES.map(value => [value, CATEGORY_LABELS[value]])]
    .map(([value, label]) => `<option value="${value}">${label}</option>`).join("");

  let slotMarkup = "";
  let linkLayoutMarkup = "";
  let slotRulesMarkup = "";
  if (host.enabled && host.slotCount > 0) {
    const parts = [];
    const ruleRows = [];
    for (let index = 0; index < host.slotCount; index++) {
      const slot = host.slots[index];
      const hasSlot = Boolean(slot?.uuid || isStoredSlot(slot));
      const display = slotDisplay(slot);
      const group = linkedGroupIndices(host, index);
      const status = host.statuses?.[index] ?? {};
      const category = status.category ?? (isStoredSlot(slot) ? getMateriaFromData(slot.itemData).category : "other");
      const statusClass = status.empty ? "empty" : status.suppressedBy?.length ? "suppressed" : status.active ? "active" : "inactive";
      const statusText = status.empty ? "Empty" : status.suppressedBy?.length ? "Suppressed" : status.active ? "Active" : "Inactive";
      const linkBadge = group.length
        ? `<span class="gms-slot-link-label"><i class="fa-solid fa-link"></i> Group: ${[index, ...group].sort((a,b)=>a-b).map(partner => `Slot ${partner + 1}`).join(", ")}</span>`
        : "";
      const progressBadge = status.level
        ? `<span class="gms-slot-progress">Lv ${status.level}${status.mastered ? " • MASTERED" : ""}${status.ap !== null && status.ap !== undefined ? ` • ${status.ap} AP` : ""}</span>`
        : "";
      const reason = status.reason ? `<span class="gms-slot-reason" title="${escapeHTML(status.reason)}">${escapeHTML(status.reason)}</span>` : "";

      parts.push(`<div class="gms-slot ${hasSlot ? "filled" : "empty"} ${group.length ? "linked" : ""} ${categoryCss(category)} gms-status-${statusClass}" data-slot-index="${index}" title="${escapeHTML(status.reason || "Drag a configured Materia Item here")}">
        <div class="gms-socket-ring"><img src="${escapeHTML(display.img)}" alt="" /></div>
        <div class="gms-slot-copy">
          <strong>Slot ${index + 1}</strong>
          <span>${escapeHTML(display.name)}</span>
          <span class="gms-status-badge ${statusClass}">${statusText}</span>
          ${progressBadge}
          ${linkBadge}
          ${reason}
        </div>
        ${hasSlot && editable ? `<button type="button" class="gms-icon-button" data-action="remove-slot" data-slot-index="${index}" title="Remove Materia and return it to inventory"><i class="fa-solid fa-xmark"></i></button>` : ""}
      </div>`);

      const rule = host.slotRules?.[index] ?? DEFAULT_SLOT_RULE;
      const optionsForRule = categoryRuleOptions.replace(`value="${escapeHTML(rule.category)}"`, `value="${escapeHTML(rule.category)}" selected`);
      ruleRows.push(`<div class="gms-slot-rule-row">
        <strong>Slot ${index + 1}</strong>
        <select data-field="slot-rule-category-${index}" ${disabled}>${optionsForRule}</select>
        <input type="text" data-field="slot-rule-uuids-${index}" value="${escapeHTML(rule.uuids)}" placeholder="Allowed UUIDs, comma-separated" ${disabled}/>
      </div>`);
    }
    slotMarkup = `<div class="gms-slots gms-appearance-${host.appearance} gms-orientation-${host.orientation}">${parts.join("")}</div>`;
    slotRulesMarkup = `<div class="gms-slot-rules">${ruleRows.join("")}</div>`;

    if (host.slotCount >= 2) {
      const linkButtons = [];
      for (let a = 0; a < host.slotCount - 1; a++) {
        for (let b = a + 1; b < host.slotCount; b++) {
          const active = isExactLink(host, a, b);
          linkButtons.push(`<button type="button" class="gms-link-button ${active ? "active" : ""}" data-action="toggle-link" data-link-a="${a}" data-link-b="${b}" ${editable ? "" : "disabled"} title="${active ? "Remove" : "Create"} direct link between Slot ${a + 1} and Slot ${b + 1}">
            <i class="fa-solid fa-link"></i> ${a + 1} ↔ ${b + 1}
          </button>`);
        }
      }
      linkLayoutMarkup = `<details class="gms-subcard gms-link-layout" data-collapse-section="host-links" ${linkLayoutOpen ? "open" : ""}>
        <summary class="gms-subcard-summary"><span><i class="fa-solid fa-diagram-project"></i><strong>Link Layout</strong></span><i class="fa-solid fa-chevron-down gms-collapse-chevron"></i></summary>
        <div class="gms-subcard-body">
          <p class="gms-muted">Toggle any slot-to-slot connections. Direct and transitive connections form one linked group; branches, long chains, and multiple independent groups are supported.</p>
          <div class="gms-link-matrix">${linkButtons.join("")}</div>
        </div>
      </details>`;
    }
  } else {
    slotMarkup = `<p class="gms-muted">Enable Materia and choose at least one slot to create drop targets.</p>`;
  }

  const categoryChecks = CATEGORY_VALUES.map(category => `<label class="gms-check"><input type="checkbox" data-field="host-allowed-category-${category}" ${host.allowedCategories.includes(category) ? "checked" : ""} ${disabled}/> ${CATEGORY_LABELS[category]}</label>`).join("");

  return `<details class="gms-card gms-host-card" data-collapse-section="host" ${sectionOpen ? "open" : ""}>
    <summary class="gms-card-summary"><span><i class="fa-solid fa-gem"></i><strong>Equipment Materia</strong></span><i class="fa-solid fa-chevron-down gms-collapse-chevron"></i></summary>
    <div class="gms-card-body">
      <div class="gms-grid gms-grid-2">
        <label class="gms-check"><input type="checkbox" data-field="host-enabled" ${host.enabled ? "checked" : ""} ${disabled}/> Enable Materia on this equipment</label>
        <label>Slots<select data-field="slot-count" ${disabled}>${options}</select></label>
      </div>
      ${slotMarkup}
      ${linkLayoutMarkup}

      <details class="gms-subcard" data-collapse-section="host-growth" ${growthOpen ? "open" : ""}>
        <summary class="gms-subcard-summary"><span><i class="fa-solid fa-chart-line"></i><strong>AP Growth</strong></span><i class="fa-solid fa-chevron-down gms-collapse-chevron"></i></summary>
        <div class="gms-subcard-body">
          <div class="gms-grid gms-grid-2">
            <label>Growth Rate<select data-field="host-growth-mode" ${disabled}>${growthOptions}</select></label>
            <label>Custom Multiplier<input type="number" min="0" step="0.1" data-field="host-custom-growth" value="${host.customGrowth}" ${disabled}/></label>
          </div>
          <p class="gms-muted">AP awarded through the Materia Manager is multiplied by this equipment's growth rate. None disables AP growth for Materia in this item.</p>
        </div>
      </details>

      <details class="gms-subcard" data-collapse-section="host-appearance" ${appearanceOpen ? "open" : ""}>
        <summary class="gms-subcard-summary"><span><i class="fa-solid fa-palette"></i><strong>Slot Appearance</strong></span><i class="fa-solid fa-chevron-down gms-collapse-chevron"></i></summary>
        <div class="gms-subcard-body">
          <div class="gms-grid gms-grid-2">
            <label>Style<select data-field="host-appearance" ${disabled}>${appearanceOptions}</select></label>
            <label>Orientation<select data-field="host-orientation" ${disabled}>${orientationOptions}</select></label>
          </div>
          <p class="gms-muted">Compact Sockets uses the Materia type color for the socket ring; Detailed Cards keeps full status and diagnostics visible.</p>
        </div>
      </details>

      <details class="gms-subcard" data-collapse-section="host-rules" ${rulesOpen ? "open" : ""}>
        <summary class="gms-subcard-summary"><span><i class="fa-solid fa-shield-halved"></i><strong>Equipment & Slot Rules</strong></span><i class="fa-solid fa-chevron-down gms-collapse-chevron"></i></summary>
        <div class="gms-subcard-body">
          <p class="gms-muted">Leave category and UUID restrictions empty to allow any Materia. UUID lists are comma-separated exact matches.</p>
          <div class="gms-category-checks">${categoryChecks}</div>
          <label>Allowed Materia UUIDs <span class="gms-optional">(optional)</span><input type="text" data-field="host-allowed-uuids" value="${escapeHTML(host.allowedUuids)}" placeholder="UUIDs, separated by a comma" ${disabled}/></label>
          <div class="gms-grid gms-grid-2">
            <label class="gms-check"><input type="checkbox" data-field="host-require-equipped" ${host.requireEquipped ? "checked" : ""} ${disabled}/> Effects require equipment to be equipped</label>
            <label class="gms-check"><input type="checkbox" data-field="host-require-attuned" ${host.requireAttuned ? "checked" : ""} ${disabled}/> Effects require attunement</label>
            <label>Minimum Rarity<select data-field="host-min-rarity" ${disabled}>${rarityOptions}</select></label>
            <label>Required Equipment Properties<input type="text" data-field="host-required-properties" value="${escapeHTML(host.requiredProperties)}" placeholder="property keys, separated by a comma" ${disabled}/></label>
          </div>
          ${slotRulesMarkup ? `<div class="gms-rule-separator"></div><strong>Per-Slot Rules</strong>${slotRulesMarkup}` : ""}
        </div>
      </details>

      ${editable ? `<button type="button" data-action="save-host"><i class="fa-solid fa-floppy-disk"></i> Save Equipment Materia</button>` : ""}
    </div>
  </details>`;
}

function materiaSection(item, materia, editable, openSections = null) {
  const disabled = editable ? "" : "disabled";
  const sectionOpen = isSectionOpen(openSections, "materia");
  const linkSectionOpen = isSectionOpen(openSections, "materia-link");
  const progressionOpen = isSectionOpen(openSections, "materia-progression");
  const grantsOpen = isSectionOpen(openSections, "materia-grants");
  const modifierOpen = isSectionOpen(openSections, "materia-modifiers");
  const categoryOptions = CATEGORY_VALUES.map(value =>
    `<option value="${value}" ${materia.category === value ? "selected" : ""}>${CATEGORY_LABELS[value]}</option>`
  ).join("");
  const allowed = [
    ["both", "Weapons & Equipment"],
    ["weapon", "Weapons Only"],
    ["equipment", "Equipment/Armor Only"]
  ].map(([value, label]) => `<option value="${value}" ${materia.allowed === value ? "selected" : ""}>${label}</option>`).join("");

  const effectTimingOptions = [
    ["always", "Always while slotted"],
    ["linked", "Only while validly linked"]
  ].map(([value, label]) => `<option value="${value}" ${materia.effectTiming === value ? "selected" : ""}>${label}</option>`).join("");

  const requirementChoices = [["any", "Any Materia"], ["non-support", "Any non-Support Materia"], ...CATEGORY_VALUES.map(value => [value, CATEGORY_LABELS[value]])];
  const requirementOptions = requirementChoices
    .map(([value, label]) => `<option value="${value}" ${materia.linkRequirement === value ? "selected" : ""}>${label}</option>`).join("");
  const suppressionRequirementOptions = requirementChoices
    .map(([value, label]) => `<option value="${value}" ${materia.suppressionRequirement === value ? "selected" : ""}>${label}</option>`).join("");
  const suppressionScopeOptions = [
    ["linked-group", "Only Materia in this linked group"],
    ["equipment", "Any Materia on this equipment"]
  ].map(([value, label]) => `<option value="${value}" ${materia.suppressionScope === value ? "selected" : ""}>${label}</option>`).join("");
  const masteryOptions = [
    ["none", "Do Nothing"], ["notify", "GM Notification"], ["chat", "Chat Message"], ["duplicate", "Create New Level 1 Copy"]
  ].map(([value, label]) => `<option value="${value}" ${materia.progression.masteryBehavior === value ? "selected" : ""}>${label}</option>`).join("");
  const maxLevelOptions = Array.from({ length: MAX_LEVELS }, (_, index) => index + 1)
    .map(level => `<option value="${level}" ${materia.progression.maxLevel === level ? "selected" : ""}>${level}</option>`).join("");

  const currentLevel = currentMateriaLevel(materia);
  const levelCards = materia.progression.levels.map((profile, index) => {
    const level = index + 1;
    const open = isSectionOpen(openSections, `materia-level-${level}`);
    const levelEffectTimingOptions = [["inherit", "Inherit Base"], ["always", "Always While Slotted"], ["linked", "Only While Linked"]]
      .map(([value, label]) => `<option value="${value}" ${profile.effectTiming === value ? "selected" : ""}>${label}</option>`).join("");
    const levelRequirementOptions = [["inherit", "Inherit Base"], ...requirementChoices]
      .map(([value, label]) => `<option value="${value}" ${profile.linkRequirement === value ? "selected" : ""}>${label}</option>`).join("");
    const levelSuppressionBehaviorOptions = [["inherit", "Inherit Base"], ["on", "Force On"], ["off", "Force Off"]]
      .map(([value, label]) => `<option value="${value}" ${profile.suppressionBehavior === value ? "selected" : ""}>${label}</option>`).join("");
    const levelSuppressionScopeOptions = [["inherit", "Inherit Base"], ["linked-group", "Linked Group"], ["equipment", "Entire Equipment"]]
      .map(([value, label]) => `<option value="${value}" ${profile.suppressionScope === value ? "selected" : ""}>${label}</option>`).join("");
    const levelSuppressionRequirementOptions = [["inherit", "Inherit Base"], ...requirementChoices]
      .map(([value, label]) => `<option value="${value}" ${profile.suppressionRequirement === value ? "selected" : ""}>${label}</option>`).join("");
    return `<details class="gms-level-card" data-collapse-section="materia-level-${level}" ${open ? "open" : ""}>
      <summary><span><strong>Level ${level}</strong>${level === currentLevel ? `<span class="gms-current-level">Current</span>` : ""}</span><span>${profile.threshold} AP</span></summary>
      <div class="gms-level-body">
        <div class="gms-grid gms-grid-2">
          <label>AP Threshold<input type="number" min="0" step="1" data-field="level-threshold-${index}" value="${profile.threshold}" ${disabled}/></label>
          <label>Active Effect IDs / UUIDs <span class="gms-optional">(blank = all)</span><input type="text" data-field="level-effect-uuids-${index}" value="${escapeHTML(profile.effectUuids)}" placeholder="IDs or UUIDs, comma-separated" ${disabled}/></label>
          <label>Effect Timing Override<select data-field="level-effect-timing-${index}" ${disabled}>${levelEffectTimingOptions}</select></label>
          <label>Linked Requirement Override<select data-field="level-link-requirement-${index}" ${disabled}>${levelRequirementOptions}</select></label>
          <label>Partner UUID Override <span class="gms-optional">(blank = inherit)</span><input type="text" data-field="level-partner-uuids-${index}" value="${escapeHTML(profile.partnerUuids)}" placeholder="UUIDs, separated by a comma" ${disabled}/></label>
          <label>Suppression Override<select data-field="level-suppression-behavior-${index}" ${disabled}>${levelSuppressionBehaviorOptions}</select></label>
          <label>Suppression Scope Override<select data-field="level-suppression-scope-${index}" ${disabled}>${levelSuppressionScopeOptions}</select></label>
          <label>Suppression Target Override<select data-field="level-suppression-requirement-${index}" ${disabled}>${levelSuppressionRequirementOptions}</select></label>
          <label>Suppression UUID Override <span class="gms-optional">(blank = inherit)</span><input type="text" data-field="level-suppression-uuids-${index}" value="${escapeHTML(profile.suppressionUuids)}" placeholder="UUIDs, separated by a comma" ${disabled}/></label>
          <label>Additional Prefix<input type="text" data-field="level-prefix-${index}" value="${escapeHTML(profile.prefix)}" ${disabled}/></label>
          <label>Additional Suffix<input type="text" data-field="level-suffix-${index}" value="${escapeHTML(profile.suffix)}" ${disabled}/></label>
          <label>Additional Linked Prefix<input type="text" data-field="level-linked-prefix-${index}" value="${escapeHTML(profile.linkedPrefix)}" ${disabled}/></label>
          <label>Additional Linked Suffix<input type="text" data-field="level-linked-suffix-${index}" value="${escapeHTML(profile.linkedSuffix)}" ${disabled}/></label>
        </div>
        <label>Additional Slot Description<textarea rows="2" data-field="level-slot-text-${index}" ${disabled}>${escapeHTML(profile.slotText)}</textarea></label>
        <label>Additional Linked Description<textarea rows="2" data-field="level-linked-text-${index}" ${disabled}>${escapeHTML(profile.linkedText)}</textarea></label>
        <label>Granted Item UUIDs at this Level<input type="text" data-field="level-grant-uuids-${index}" value="${escapeHTML(profile.grantUuids)}" placeholder="UUIDs, separated by a comma" ${disabled}/></label>
      </div>
    </details>`;
  }).join("");

  const modifierModeOptions = selected => Object.keys(EFFECT_MODES)
    .map(mode => `<option value="${mode}" ${selected === mode ? "selected" : ""}>${mode[0].toUpperCase()}${mode.slice(1)}</option>`).join("");
  const modifierRows = Array.from({ length: 8 }, (_, index) => {
    const rule = materia.linkedModifiers[index] ?? { path: "", mode: "override", value: "" };
    return `<div class="gms-modifier-row">
      <input type="text" data-field="modifier-path-${index}" value="${escapeHTML(rule.path)}" placeholder="system.path.to.field" ${disabled}/>
      <select data-field="modifier-mode-${index}" ${disabled}>${modifierModeOptions(rule.mode)}</select>
      <input type="text" data-field="modifier-value-${index}" value="${escapeHTML(rule.value)}" placeholder="Value" ${disabled}/>
    </div>`;
  }).join("");

  return `<details class="gms-card gms-materia-card" data-collapse-section="materia" ${sectionOpen ? "open" : ""}>
    <summary class="gms-card-summary"><span><i class="fa-solid fa-circle-dot"></i><strong>Materia Item</strong></span><i class="fa-solid fa-chevron-down gms-collapse-chevron"></i></summary>
    <div class="gms-card-body">
      <div class="gms-uuid-row"><code>${escapeHTML(item.uuid)}</code><button type="button" data-action="copy-uuid" title="Copy this Item UUID"><i class="fa-solid fa-copy"></i> Copy UUID</button></div>
      <label class="gms-check"><input type="checkbox" data-field="materia-enabled" ${materia.enabled ? "checked" : ""} ${disabled}/> This Item is Materia</label>
      <div class="gms-grid gms-grid-2">
        <label>Materia Type<select data-field="materia-category" ${disabled}>${categoryOptions}</select></label>
        <label>Allowed Equipment<select data-field="materia-allowed" ${disabled}>${allowed}</select></label>
        <label>Prefix<input type="text" data-field="materia-prefix" value="${escapeHTML(materia.prefix)}" placeholder="Flaming" ${disabled}/></label>
        <label>Suffix<input type="text" data-field="materia-suffix" value="${escapeHTML(materia.suffix)}" placeholder="of Embers" ${disabled}/></label>
      </div>
      <label>Slot Description Text<textarea data-field="materia-text" rows="2" placeholder="Flames dance along the weapon's edge." ${disabled}>${escapeHTML(materia.slotText)}</textarea></label>
      <label class="gms-check"><input type="checkbox" data-field="materia-copy-effects" ${materia.copyEffects ? "checked" : ""} ${disabled}/> Copy this Materia's Active Effects onto slotted equipment</label>
      <p class="gms-muted">Standard Actor effects transfer through the equipment. Item/enchantment effects are copied as item enchantments where D&D5e supports them.</p>

      <details class="gms-subcard" data-collapse-section="materia-grants" ${grantsOpen ? "open" : ""}>
        <summary class="gms-subcard-summary"><span><i class="fa-solid fa-wand-magic-sparkles"></i><strong>Granted Abilities / Items</strong></span><i class="fa-solid fa-chevron-down gms-collapse-chevron"></i></summary>
        <div class="gms-subcard-body">
          <label>Always Granted Item UUIDs<input type="text" data-field="materia-grant-uuids" value="${escapeHTML(materia.grantUuids)}" placeholder="UUIDs, separated by a comma" ${disabled}/></label>
          <p class="gms-muted">When this Materia is active on Actor-owned equipment, copies of these Items are granted to the Actor and automatically removed when the Materia or equipment stops providing them.</p>
        </div>
      </details>

      <details class="gms-subcard" data-collapse-section="materia-progression" ${progressionOpen ? "open" : ""}>
        <summary class="gms-subcard-summary"><span><i class="fa-solid fa-star"></i><strong>AP, Levels & Mastery</strong></span><i class="fa-solid fa-chevron-down gms-collapse-chevron"></i></summary>
        <div class="gms-subcard-body">
          <div class="gms-grid gms-grid-2">
            <label class="gms-check"><input type="checkbox" data-field="progression-enabled" ${materia.progression.enabled ? "checked" : ""} ${disabled}/> Enable AP progression</label>
            <label>Current AP<input type="number" min="0" step="1" data-field="progression-ap" value="${materia.progression.ap}" ${disabled}/></label>
            <label>Maximum Level<select data-field="progression-max-level" ${disabled}>${maxLevelOptions}</select></label>
            <label>On Mastery<select data-field="progression-mastery" ${disabled}>${masteryOptions}</select></label>
          </div>
          <div class="gms-progress-summary"><strong>Current Level: ${currentLevel}/${materia.progression.maxLevel}</strong><span>${materiaMastered(materia) ? "MASTERED" : `${materia.progression.ap} AP`}</span></div>
          <p class="gms-muted">Level profiles add to the Materia's base text and affixes. If an Active Effect list is supplied for a level, only those effect IDs/UUIDs are copied at that level.</p>
          <div class="gms-level-list">${levelCards}</div>
        </div>
      </details>

      <details class="gms-subcard" data-collapse-section="materia-link" ${linkSectionOpen ? "open" : ""}>
        <summary class="gms-subcard-summary"><span><i class="fa-solid fa-link"></i><strong>Linked / Support Behavior</strong></span><i class="fa-solid fa-chevron-down gms-collapse-chevron"></i></summary>
        <div class="gms-subcard-body">
          <p class="gms-muted">Linked behavior can validate against any Materia in the connected slot group. Exact partner and suppression rules accept multiple UUIDs.</p>
          <div class="gms-grid gms-grid-2">
            <label>Active Effect Activation<select data-field="materia-effect-timing" ${disabled}>${effectTimingOptions}</select></label>
            <label>Required Linked Partner<select data-field="materia-link-requirement" ${disabled}>${requirementOptions}</select></label>
            <label>Exact Partner UUIDs <span class="gms-optional">(optional)</span><input type="text" data-field="materia-partner-uuids" value="${escapeHTML(materia.partnerUuids)}" placeholder="Insert UUID's Here, separated by a comma." ${disabled}/><span class="gms-field-hint">Insert UUID's Here, separated by a comma.</span></label>
            <label>Linked Prefix<input type="text" data-field="materia-linked-prefix" value="${escapeHTML(materia.linkedPrefix)}" placeholder="Empowered" ${disabled}/></label>
            <label>Linked Suffix<input type="text" data-field="materia-linked-suffix" value="${escapeHTML(materia.linkedSuffix)}" placeholder="of Elemental Fire" ${disabled}/></label>
            <label>Linked Granted Item UUIDs<input type="text" data-field="materia-linked-grant-uuids" value="${escapeHTML(materia.linkedGrantUuids)}" placeholder="UUIDs, separated by a comma" ${disabled}/></label>
          </div>
          <label>Linked Description Text<textarea data-field="materia-linked-text" rows="2" placeholder="This effect is active only while the linked partner requirement is met." ${disabled}>${escapeHTML(materia.linkedText)}</textarea></label>

          <div class="gms-rule-separator"></div>
          <label class="gms-check"><input type="checkbox" data-field="materia-suppress-effects" ${materia.suppressEffects ? "checked" : ""} ${disabled}/> Suppress Active Effects from other Materia while this linked behavior is active</label>
          <div class="gms-grid gms-grid-2">
            <label>Suppression Scope<select data-field="materia-suppression-scope" ${disabled}>${suppressionScopeOptions}</select></label>
            <label>Materia to Suppress<select data-field="materia-suppression-requirement" ${disabled}>${suppressionRequirementOptions}</select></label>
            <label>Exact Suppressed Materia UUIDs <span class="gms-optional">(optional)</span><input type="text" data-field="materia-suppression-uuids" value="${escapeHTML(materia.suppressionUuids)}" placeholder="Insert UUID's Here, separated by a comma." ${disabled}/><span class="gms-field-hint">Insert UUID's Here, separated by a comma.</span></label>
          </div>
          <p class="gms-muted">Suppression prevents matching Materia from contributing Active Effects. Their descriptions and affixes remain intact.</p>

          <details class="gms-subcard gms-inner-card" data-collapse-section="materia-modifiers" ${modifierOpen ? "open" : ""}>
            <summary class="gms-subcard-summary"><span><i class="fa-solid fa-sliders"></i><strong>Specialized Linked Modifier Rules</strong></span><i class="fa-solid fa-chevron-down gms-collapse-chevron"></i></summary>
            <div class="gms-subcard-body">
              <p class="gms-muted">These rules create a generated D&D5e Item enchantment only while the linked partner requirement is valid. Use D&D5e item data paths to build Elemental-, Magnify-, Added Effect-, absorb-, counter-, or other campaign-specific Support behavior without hard-coded spell names.</p>
              <div class="gms-modifier-header"><span>Item Data Path</span><span>Mode</span><span>Value</span></div>
              <div class="gms-modifier-list">${modifierRows}</div>
            </div>
          </details>
        </div>
      </details>

      ${editable ? `<button type="button" data-action="save-materia"><i class="fa-solid fa-floppy-disk"></i> Save Materia Item</button>` : ""}
    </div>
  </details>`;
}

function buildPanel(item, { openSections = null } = {}) {
  const editable = canEdit(item);
  const host = getHost(item);
  const materia = getMateria(item);
  const wrapper = document.createElement("section");
  wrapper.className = "geofen-materia-panel";
  wrapper.dataset.itemUuid = item.uuid;
  const panelOpen = isSectionOpen(openSections, "panel");
  wrapper.innerHTML = `<details data-collapse-section="panel" ${panelOpen ? "open" : ""}>
    <summary><i class="fa-solid fa-gem"></i> Geofen's : Materia System <span class="gms-version">v${VERSION}</span></summary>
    <div class="gms-panel-body">
      ${hostSection(item, host, editable, openSections)}
      ${materiaSection(item, materia, editable, openSections)}
    </div>
  </details>`;
  return wrapper;
}

function bindPanel(item, panel) {
  panel.querySelector('[data-action="save-host"]')?.addEventListener("click", () => saveHostConfiguration(item, panel));
  panel.querySelector('[data-action="save-materia"]')?.addEventListener("click", () => saveMateriaConfiguration(item, panel));
  panel.querySelector('[data-action="copy-uuid"]')?.addEventListener("click", async event => {
    event.preventDefault();
    try {
      if (game.clipboard?.copyPlainText) await game.clipboard.copyPlainText(item.uuid);
      else await navigator.clipboard?.writeText?.(item.uuid);
      notify(`Copied UUID: ${item.uuid}`);
    } catch (error) {
      warn("Could not copy Item UUID", error);
      notify(`UUID: ${item.uuid}`, "warn");
    }
  });

  for (const button of panel.querySelectorAll('[data-action="remove-slot"]')) {
    button.addEventListener("click", event => {
      event.preventDefault();
      event.stopPropagation();
      removeSlot(item, Number(button.dataset.slotIndex), panel);
    });
  }

  for (const button of panel.querySelectorAll('[data-action="toggle-link"]')) {
    button.addEventListener("click", event => {
      event.preventDefault();
      event.stopPropagation();
      toggleLink(item, Number(button.dataset.linkA), Number(button.dataset.linkB), panel);
    });
  }

  const categorySelect = panel.querySelector('[data-field="materia-category"]');
  const effectTimingSelect = panel.querySelector('[data-field="materia-effect-timing"]');
  let effectTimingTouched = false;
  effectTimingSelect?.addEventListener("change", () => { effectTimingTouched = true; });
  categorySelect?.addEventListener("change", () => {
    if (categorySelect.value === "support" && effectTimingSelect && !effectTimingTouched) {
      effectTimingSelect.value = "linked";
    }
  });

  for (const slot of panel.querySelectorAll(".gms-slot")) {
    slot.addEventListener("dragover", event => {
      event.preventDefault();
      slot.classList.add("dragover");
    });
    slot.addEventListener("dragleave", () => slot.classList.remove("dragover"));
    slot.addEventListener("drop", event => {
      slot.classList.remove("dragover");
      slotMateria(item, Number(slot.dataset.slotIndex), event, panel);
    });
  }
}

function injectPanel(application, element) {
  if (game.system.id !== "dnd5e") return;
  const item = application.document ?? application.item ?? application.object;
  if (!isItemDocument(item)) return;
  if (!canViewMateriaPanel(item)) return;
  if (element.querySelector?.(".geofen-materia-panel")) return;

  const panel = buildPanel(item);
  // ApplicationV2 item sheets are assembled from independent render parts/forms.
  // Append to the sheet content root rather than nesting inside one system-owned form.
  element.append(panel);
  bindPanel(item, panel);
}

async function restoreAllStoredSlots(hostItem, { clear = true, quiet = false } = {}) {
  const raw = getRawHost(hostItem);
  const slots = Array.isArray(raw.slots) ? raw.slots : [];
  let restored = 0;
  for (let i = 0; i < slots.length; i++) {
    const slot = slots[i];
    if (!isStoredSlot(slot)) continue;
    try {
      const ok = await restoreStoredMateria(hostItem, slot, { quiet });
      if (!ok) continue;
      restored++;
      if (clear) slots[i] = null;
    } catch (error) {
      warn(`Could not restore stored Materia from ${hostItem.name} Slot ${i + 1}`, error);
    }
  }
  if (clear && restored) {
    raw.slots = slots;
    await hostItem.setFlag(MODULE_ID, "host", raw);
    await rebuildHost(hostItem, { render: false });
    refreshVisiblePanels(hostItem);
  }
  return restored;
}

async function scanDiagnostics() {
  const issues = [];
  const storageIds = new Map();
  for (const hostItem of allHostItems()) {
    const raw = getRawHost(hostItem);
    const host = getHost(hostItem);
    const rawSlots = Array.isArray(raw.slots) ? raw.slots : [];

    for (let i = host.slotCount; i < rawSlots.length; i++) {
      if (!rawSlots[i]) continue;
      issues.push({ severity: "error", hostUuid: hostItem.uuid, hostName: hostItem.name, slot: i + 1, code: "orphan-beyond-count", message: "Stored slot exists beyond the configured slot count." });
    }

    for (let i = 0; i < host.slots.length; i++) {
      const slot = host.slots[i];
      if (!slot) continue;
      if (isStoredSlot(slot)) {
        if (!slot.itemData?.flags?.[MODULE_ID]?.materia) {
          issues.push({ severity: "error", hostUuid: hostItem.uuid, hostName: hostItem.name, slot: i + 1, code: "stored-missing-flags", message: "Stored Item data is missing Materia configuration." });
        }
        if (slot.storageId) {
          const key = String(slot.storageId);
          if (storageIds.has(key)) {
            issues.push({ severity: "warn", hostUuid: hostItem.uuid, hostName: hostItem.name, slot: i + 1, code: "duplicate-storage-id", message: `Storage ID is also used by ${storageIds.get(key)}.` });
          } else storageIds.set(key, `${hostItem.name} Slot ${i + 1}`);
        }
      } else if (slot.uuid) {
        let source = null;
        try { source = await fromUuid(slot.uuid); } catch (_error) {}
        if (!isItemDocument(source)) {
          issues.push({ severity: "error", hostUuid: hostItem.uuid, hostName: hostItem.name, slot: i + 1, code: "missing-template", message: `Template UUID cannot be resolved: ${slot.uuid}` });
        } else if (!getMateria(source).enabled) {
          issues.push({ severity: "warn", hostUuid: hostItem.uuid, hostName: hostItem.name, slot: i + 1, code: "template-not-materia", message: "Referenced Item is no longer configured as Materia." });
        }
      }
    }
  }
  return issues;
}

async function repairHost(hostItem) {
  if (!isSupportedHost(hostItem) || !canEdit(hostItem)) return { repaired: 0, returned: 0 };
  const raw = getRawHost(hostItem);
  const host = getHost(hostItem);
  const rawSlots = Array.isArray(raw.slots) ? raw.slots : [];
  let repaired = 0;
  let returned = 0;

  // Return stored Items hidden beyond the configured slot count before normalization discards them.
  for (let i = host.slotCount; i < rawSlots.length; i++) {
    const slot = rawSlots[i];
    if (!slot) continue;
    if (isStoredSlot(slot)) {
      if (await restoreStoredMateria(hostItem, slot, { quiet: true })) returned++;
    }
    rawSlots[i] = null;
    repaired++;
  }

  host.slots = Array.from({ length: host.slotCount }, (_, index) => rawSlots[index] ?? host.slots[index] ?? null);
  for (let i = 0; i < host.slots.length; i++) {
    const slot = host.slots[i];
    if (!slot) continue;
    if (isStoredSlot(slot)) {
      const materia = getMateriaFromData(slot.itemData);
      if (!materia.enabled) {
        if (await restoreStoredMateria(hostItem, slot, { quiet: true })) returned++;
        host.slots[i] = null;
        repaired++;
      }
      continue;
    }
    let source = null;
    try { source = await fromUuid(slot.uuid); } catch (_error) {}
    if (!isItemDocument(source) || !getMateria(source).enabled) {
      host.slots[i] = null;
      repaired++;
    }
  }
  host.links = normalizeLinks(host.links, host.slotCount);
  host.slotRules = normalizeSlotRules(host.slotRules, host.slotCount);
  await hostItem.setFlag(MODULE_ID, "host", host);
  await rebuildHost(hostItem, { render: false });
  refreshVisiblePanels(hostItem);
  return { repaired, returned };
}

async function repairAllHosts() {
  const summary = { repaired: 0, returned: 0, hosts: 0 };
  for (const host of allHostItems()) {
    if (!canEdit(host)) continue;
    const result = await repairHost(host);
    if (result.repaired || result.returned) summary.hosts++;
    summary.repaired += result.repaired;
    summary.returned += result.returned;
  }
  return summary;
}

async function rebuildAllHosts() {
  let count = 0;
  for (const host of allHostItems()) {
    if (!canEdit(host) || !getHost(host).enabled) continue;
    await rebuildHost(host, { render: false });
    refreshVisiblePanels(host);
    count++;
  }
  return count;
}

function worldMateriaItems() {
  return (game.items ?? []).filter(item => getMateria(item).enabled);
}

function availableItemTypes() {
  const configured = Object.keys(globalThis.CONFIG?.Item?.typeLabels ?? {});
  const fallback = ["loot", "feat", "consumable", "spell"];
  return configured.length ? configured : fallback;
}

async function createMateriaDefinition(type = "loot") {
  const itemType = availableItemTypes().includes(type) ? type : (availableItemTypes()[0] ?? "loot");
  const data = {
    name: "New Materia",
    type: itemType,
    img: "icons/svg/crystal-ball.svg",
    flags: { [MODULE_ID]: { materia: normalizeMateriaData({ enabled: true }) } }
  };
  const item = await Item.create(data, { [INTERNAL_OPTION]: { internal: true, library: true } });
  if (item?.sheet?.render) await item.sheet.render(true);
  return item;
}

async function duplicateMateriaDefinition(item) {
  if (!isItemDocument(item)) return null;
  const data = item.toObject();
  delete data._id;
  delete data._stats;
  data.name = `${item.name} Copy`;
  return Item.create(data, { [INTERNAL_OPTION]: { internal: true, library: true } });
}

function exportMateriaDefinitions(items = worldMateriaItems()) {
  const payload = {
    module: MODULE_ID,
    version: VERSION,
    exportedAt: new Date().toISOString(),
    items: items.map(item => {
      const data = item.toObject();
      delete data._stats;
      return data;
    })
  };
  foundry.utils.saveDataToFile(JSON.stringify(payload, null, 2), "application/json", `geofen-materia-library-${VERSION}.json`);
}

async function importMateriaDefinitions(text) {
  let parsed;
  try { parsed = JSON.parse(String(text ?? "")); } catch (_error) { throw new Error("Import text is not valid JSON."); }
  const source = Array.isArray(parsed) ? parsed : Array.isArray(parsed?.items) ? parsed.items : [parsed];
  const creations = [];
  for (const entry of source) {
    if (!entry || typeof entry !== "object") continue;
    const data = clone(entry);
    delete data._id;
    delete data._stats;
    delete data.ownership;
    const materia = getMateriaFromData(data);
    if (!materia.enabled) continue;
    setMateriaOnItemData(data, materia);
    creations.push(data);
  }
  if (!creations.length) throw new Error("No enabled Materia Item definitions were found in that JSON.");
  return Item.createDocuments(creations, { [INTERNAL_OPTION]: { internal: true, library: true } });
}

const BaseApplicationV2 = foundry.applications.api.ApplicationV2;

class MateriaLibraryApp extends BaseApplicationV2 {
  static DEFAULT_OPTIONS = {
    id: "geofen-materia-library",
    classes: ["geofen-materia-tool-app"],
    window: { title: "Geofen's : Materia Library", resizable: true },
    position: { width: 760, height: 680 }
  };

  async _renderHTML() {
    const root = document.createElement("div");
    root.className = "gms-tool-body";
    const items = worldMateriaItems();
    const rows = items.map(item => {
      const materia = getMateria(item);
      return `<div class="gms-library-row" data-item-uuid="${escapeHTML(item.uuid)}">
        <img src="${escapeHTML(item.img)}" alt=""/><div><strong>${escapeHTML(item.name)}</strong><span>${CATEGORY_LABELS[materia.category]} • ${escapeHTML(item.type)} • Lv ${currentMateriaLevel(materia)}/${materia.progression.maxLevel}</span><code>${escapeHTML(item.uuid)}</code></div>
        <div class="gms-tool-actions"><button type="button" data-action="edit">Edit</button><button type="button" data-action="duplicate">Duplicate</button><button type="button" data-action="copy">Copy UUID</button></div>
      </div>`;
    }).join("");
    const typeOptions = availableItemTypes().map(type => `<option value="${escapeHTML(type)}">${escapeHTML(globalThis.CONFIG?.Item?.typeLabels?.[type] ?? type)}</option>`).join("");
    root.innerHTML = `<div class="gms-tool-toolbar"><select data-field="create-type">${typeOptions}</select><button type="button" data-action="create"><i class="fa-solid fa-plus"></i> Create Materia</button><button type="button" data-action="export"><i class="fa-solid fa-file-export"></i> Export World Library</button></div>
      <div class="gms-library-list">${rows || `<p class="gms-muted">No world-level Materia definitions exist yet.</p>`}</div>
      <details class="gms-import-card"><summary><strong>Import Materia JSON</strong></summary><textarea data-field="import-json" rows="8" placeholder="Paste exported Materia JSON here"></textarea><button type="button" data-action="import"><i class="fa-solid fa-file-import"></i> Import</button></details>`;
    return root;
  }

  _replaceHTML(result, content) { content.replaceChildren(result); }

  _onRender(context, options) {
    super._onRender?.(context, options);
    const root = this.element;
    root.querySelector('[data-action="create"]')?.addEventListener("click", async () => { await createMateriaDefinition(root.querySelector('[data-field="create-type"]')?.value ?? "loot"); await this.render(true); });
    root.querySelector('[data-action="export"]')?.addEventListener("click", () => exportMateriaDefinitions());
    root.querySelector('[data-action="import"]')?.addEventListener("click", async () => {
      try {
        const created = await importMateriaDefinitions(root.querySelector('[data-field="import-json"]')?.value ?? "");
        notify(`Imported ${created?.length ?? 0} Materia definition(s).`);
        await this.render(true);
      } catch (error) { notify(error.message ?? String(error), "error"); }
    });
    for (const row of root.querySelectorAll(".gms-library-row")) {
      const uuid = row.dataset.itemUuid;
      row.querySelector('[data-action="edit"]')?.addEventListener("click", async () => { const item = await fromUuid(uuid); await item?.sheet?.render?.(true); });
      row.querySelector('[data-action="duplicate"]')?.addEventListener("click", async () => { const item = await fromUuid(uuid); await duplicateMateriaDefinition(item); await this.render(true); });
      row.querySelector('[data-action="copy"]')?.addEventListener("click", async () => { await game.clipboard?.copyPlainText?.(uuid); notify(`Copied UUID: ${uuid}`); });
    }
  }
}

class MateriaManagerApp extends BaseApplicationV2 {
  static DEFAULT_OPTIONS = {
    id: "geofen-materia-manager",
    classes: ["geofen-materia-tool-app"],
    window: { title: "Geofen's : Materia Manager & Recovery", resizable: true },
    position: { width: 900, height: 720 }
  };

  async _renderHTML() {
    const root = document.createElement("div");
    root.className = "gms-tool-body";
    const issues = await scanDiagnostics();
    const actorOptions = (game.actors ?? []).map(actor => `<option value="${actor.id}">${escapeHTML(actor.name)}</option>`).join("");
    const issueRows = issues.map(issue => `<div class="gms-diagnostic-row ${issue.severity}"><span class="gms-diagnostic-severity">${issue.severity.toUpperCase()}</span><div><strong>${escapeHTML(issue.hostName)}${issue.slot ? ` — Slot ${issue.slot}` : ""}</strong><span>${escapeHTML(issue.message)}</span></div><button type="button" data-action="repair-host" data-host-uuid="${escapeHTML(issue.hostUuid)}">Repair Host</button></div>`).join("");
    root.innerHTML = `<section class="gms-manager-section"><h3>AP Award</h3><div class="gms-grid gms-grid-3"><label>Actor<select data-field="ap-actor">${actorOptions}</select></label><label>Base AP<input type="number" min="0" step="1" value="0" data-field="ap-amount"/></label><div class="gms-button-stack"><button type="button" data-action="award-actor">Award to Actor</button><button type="button" data-action="award-all">Award to All Actors</button></div></div><p class="gms-muted">Each enabled equipment item's growth rate multiplies the base AP. Actor-owned slotted Materia receive AP; world/Compendium template references are skipped to avoid changing shared templates.</p></section>
      <section class="gms-manager-section"><h3>Recovery & Diagnostics</h3><div class="gms-tool-toolbar"><button type="button" data-action="scan"><i class="fa-solid fa-magnifying-glass"></i> Rescan</button><button type="button" data-action="repair-all"><i class="fa-solid fa-screwdriver-wrench"></i> Repair All</button><button type="button" data-action="rebuild-all"><i class="fa-solid fa-rotate"></i> Rebuild All Hosts</button></div><div class="gms-diagnostic-list">${issueRows || `<p class="gms-success">No structural Materia issues detected.</p>`}</div></section>
      <section class="gms-manager-section"><h3>Installed Materia</h3>${this._installedTable()}</section>`;
    return root;
  }

  _installedTable() {
    const rows = [];
    for (const actor of game.actors ?? []) {
      for (const hostItem of actor.items?.filter?.(isSupportedHost) ?? []) {
        const host = getHost(hostItem);
        if (!host.enabled) continue;
        for (let i = 0; i < host.slots.length; i++) {
          const slot = host.slots[i];
          if (!slot) continue;
          const status = host.statuses?.[i] ?? {};
          rows.push(`<tr><td>${escapeHTML(actor.name)}</td><td>${escapeHTML(hostItem.name)}</td><td>${i + 1}</td><td>${escapeHTML(slotDisplay(slot).name)}</td><td>${status.level ?? "—"}</td><td>${status.ap ?? "—"}</td><td>${status.suppressedBy?.length ? "Suppressed" : status.active ? "Active" : "Inactive"}</td><td><button type="button" data-action="return-host" data-host-uuid="${escapeHTML(hostItem.uuid)}">Return All</button></td></tr>`);
        }
      }
    }
    return `<div class="gms-table-scroll"><table class="gms-manager-table"><thead><tr><th>Actor</th><th>Equipment</th><th>Slot</th><th>Materia</th><th>Level</th><th>AP</th><th>Status</th><th>Recovery</th></tr></thead><tbody>${rows.join("") || `<tr><td colspan="8">No slotted Actor-owned Materia found.</td></tr>`}</tbody></table></div>`;
  }

  _replaceHTML(result, content) { content.replaceChildren(result); }

  _onRender(context, options) {
    super._onRender?.(context, options);
    const root = this.element;
    root.querySelector('[data-action="scan"]')?.addEventListener("click", () => this.render(true));
    root.querySelector('[data-action="award-actor"]')?.addEventListener("click", async () => {
      const actor = game.actors.get(root.querySelector('[data-field="ap-actor"]')?.value);
      const amount = Number(root.querySelector('[data-field="ap-amount"]')?.value ?? 0);
      const result = await awardApToActor(actor, amount);
      notify(`${result.actor ?? "Actor"}: ${result.awarded} AP distributed to ${result.materia} slotted Materia.`);
      await this.render(true);
    });
    root.querySelector('[data-action="award-all"]')?.addEventListener("click", async () => {
      const amount = Number(root.querySelector('[data-field="ap-amount"]')?.value ?? 0);
      const results = await awardApToAllActors(amount);
      const awarded = results.reduce((sum, result) => sum + result.awarded, 0);
      const materia = results.reduce((sum, result) => sum + result.materia, 0);
      notify(`${awarded} AP distributed across ${materia} slotted Materia.`);
      await this.render(true);
    });
    root.querySelector('[data-action="repair-all"]')?.addEventListener("click", async () => { const result = await repairAllHosts(); notify(`Repair complete: ${result.repaired} issue(s) repaired; ${result.returned} stored Materia returned.`); await this.render(true); });
    root.querySelector('[data-action="rebuild-all"]')?.addEventListener("click", async () => { const count = await rebuildAllHosts(); notify(`Rebuilt ${count} Materia equipment item(s).`); await this.render(true); });
    for (const button of root.querySelectorAll('[data-action="repair-host"]')) button.addEventListener("click", async () => { const host = await fromUuid(button.dataset.hostUuid); const result = await repairHost(host); notify(`Host repaired: ${result.repaired} issue(s), ${result.returned} Materia returned.`); await this.render(true); });
    for (const button of root.querySelectorAll('[data-action="return-host"]')) button.addEventListener("click", async () => { const host = await fromUuid(button.dataset.hostUuid); const count = await restoreAllStoredSlots(host); notify(`Returned ${count} stored Materia from ${host?.name ?? "equipment"}.`); await this.render(true); });
  }
}

Hooks.once("init", () => {
  registerVisibilitySettings();
  log(`Initializing v${VERSION}`);
});

Hooks.once("ready", async () => {
  if (game.system.id !== "dnd5e") {
    notify("Geofen's : Materia System requires the D&D5e system.", "error");
    return;
  }

  const module = game.modules.get(MODULE_ID);
  if (module) {
    module.api = {
      rebuildHost,
      rebuildAllHosts,
      refreshHostsReferencing,
      getHost,
      getRawHost,
      getMateria,
      getLinkState,
      linkedPartnerIndices,
      linkedGroupIndices,
      computeSuppressedSlots,
      parseUuidList,
      exactUuidRequirementMatches,
      partnerMeetsRequirement,
      suppressionTargetMeetsRequirement,
      descriptionTerms,
      generatedDescription,
      currentMateriaLevel,
      currentLevelProfile,
      effectiveLinkedRules,
      materiaMastered,
      growthMultiplier,
      hostActivationState,
      entryAllowedByHostRules,
      prepareLinkedModifierEffect,
      buildHostStatuses,
      awardApToStoredSlot,
      awardApToActor,
      awardApToAllActors,
      scanDiagnostics,
      repairHost,
      repairAllHosts,
      restoreAllStoredSlots,
      exportMateriaDefinitions,
      importMateriaDefinitions,
      canViewMateriaPanel,
      isStoredSlot,
      makeStoredSlot,
      consumeInventoryMateria,
      restoreStoredMateria,
      version: VERSION
    };
  }

  if (game.user.isGM) {
    try {
      const migrated = game.settings.get(MODULE_ID, "migrationVersion");
      if (migrated !== VERSION) {
        const rebuilt = await rebuildAllHosts();
        await game.settings.set(MODULE_ID, "migrationVersion", VERSION);
        log(`Migrated/rebuilt ${rebuilt} host item(s) for v${VERSION}.`);
      }
    } catch (error) {
      warn("Automatic v1.0.0 migration/rebuild could not complete", error);
    }
  }
  log(`Ready on Foundry ${game.version}, D&D5e ${game.system.version}.`);
});

Hooks.on("renderApplicationV2", (application, element) => {
  try {
    injectPanel(application, element);
  } catch (error) {
    console.error(`${MODULE_ID} | Failed to render Materia panel`, error);
  }
});

Hooks.on("preUpdateItem", (item, changes, options) => {
  if (options?.[INTERNAL_OPTION]?.internal) return;
  if (!isSupportedHost(item)) return;
  const host = getHost(item);
  if (!host.enabled) return;

  if (Object.prototype.hasOwnProperty.call(changes, "name")) {
    host.baseName = String(changes.name ?? "");
    foundry.utils.setProperty(changes, `flags.${MODULE_ID}.host.baseName`, host.baseName);
  }

  const description = foundry.utils.getProperty(changes, "system.description.value");
  if (description !== undefined) {
    host.baseDescription = stripGeneratedDescription(description);
    foundry.utils.setProperty(changes, "system.description.value", host.baseDescription);
    foundry.utils.setProperty(changes, `flags.${MODULE_ID}.host.baseDescription`, host.baseDescription);
  }
});

Hooks.on("createItem", async (item, options, userId) => {
  if (options?.[INTERNAL_OPTION]?.internal) return;
  if (item.getFlag?.(MODULE_ID, "generatedGrant")) return;
  if (userId && userId !== game.user.id) return;
  if (!isSupportedHost(item) || !getHost(item).enabled) return;
  const host = getHost(item);
  let touched = false;
  for (const slot of host.slots) {
    if (!isStoredSlot(slot) || !item.actor) continue;
    // Actor duplication/import-safe snapshot ownership: restoration always targets the new host Actor.
    slot.sourceActorUuid = item.actor.uuid;
    touched = true;
  }
  if (touched) await item.setFlag(MODULE_ID, "host", host);
  await rebuildHost(item, { render: false });
});

Hooks.on("updateItem", async (item, changes, options, userId) => {
  if (options?.[INTERNAL_OPTION]?.internal) return;
  if (item.getFlag?.(MODULE_ID, "generatedGrant")) return;
  if (userId !== game.user.id) return;

  const materia = getMateria(item);
  if (materia.enabled) await refreshHostsReferencing(item.uuid);

  if (isSupportedHost(item) && getHost(item).enabled) {
    const relevant = Object.prototype.hasOwnProperty.call(changes, "name")
      || foundry.utils.getProperty(changes, "system.description.value") !== undefined
      || foundry.utils.getProperty(changes, "system.equipped") !== undefined
      || foundry.utils.getProperty(changes, "system.attuned") !== undefined
      || foundry.utils.getProperty(changes, "system.attunement") !== undefined
      || foundry.utils.getProperty(changes, "system.rarity") !== undefined
      || foundry.utils.getProperty(changes, "system.properties") !== undefined;
    if (relevant) await rebuildHost(item, { render: false });
  }
});

Hooks.on("deleteItem", async (item, options, userId) => {
  if (options?.[INTERNAL_OPTION]?.internal) return;
  if (item.getFlag?.(MODULE_ID, "generatedGrant")) return;
  if (userId !== game.user.id) return;

  if (isSupportedHost(item)) {
    const raw = getRawHost(item);
    for (const slot of Array.isArray(raw.slots) ? raw.slots : []) {
      if (!isStoredSlot(slot)) continue;
      try { await restoreStoredMateria(item, slot, { quiet: true }); }
      catch (error) { warn(`Could not recover stored Materia while deleting ${item.name}`, error); }
    }
    if (item.actor) await deleteGeneratedGrants(item.actor, item.uuid);
  }

  if (getMateria(item).enabled) await refreshHostsReferencing(item.uuid, { clearMissing: true });
});

for (const hookName of ["createActiveEffect", "updateActiveEffect", "deleteActiveEffect"]) {
  Hooks.on(hookName, async (effect, _changesOrOptions, optionsOrUserId, maybeUserId) => {
    const userId = maybeUserId ?? optionsOrUserId;
    const options = maybeUserId ? optionsOrUserId : _changesOrOptions;
    if (options?.[INTERNAL_OPTION]?.internal) return;
    if (userId && userId !== game.user.id) return;
    if (effect.getFlag?.(MODULE_ID, "generated")) return;
    const parent = effect.parent;
    if (!isItemDocument(parent)) return;
    if (!getMateria(parent).enabled) return;
    await refreshHostsReferencing(parent.uuid);
  });
}
