# Geofen's : Materia System

Version **1.0.0**, targeted specifically for **Foundry VTT 14.365** and **D&D5e 5.3.3**.

## Core Equipment System

- Enable Materia on individual weapons and equipment.
- Configure 0–8 slots.
- Drag configured Materia Items directly into slots.
- Actor-owned Materia is physically removed from inventory while slotted and returned when removed.
- Quantity stacks consume one unit at a time. If a slotted unit changes state, such as gaining AP, it is restored separately instead of being merged into an incompatible stack.
- Arbitrary slot-link graphs are supported: pairs, long chains, branches, non-adjacent links, fully-connected groups, and multiple independent groups.
- Item descriptions receive generated Materia/Slot text without destructively rewriting the original description.
- Description-only terminology settings can rename the words `Materia` and `Slot` without changing module UI labels or equipment names.
- Prefixes, suffixes, linked prefixes, linked suffixes, description text, and Active Effects are supported.
- Linked Materia can suppress Active Effects from other Materia by type and/or comma-separated exact UUIDs.
- Linked requirements and suppression rules use comma-separated exact UUID matching.

## AP, Levels, Growth, and Mastery

- Optional AP progression per Materia.
- 1–10 configurable levels.
- Each level has its own AP threshold.
- Level profiles can add slot text, linked text, prefixes, suffixes, linked affixes, granted Item UUIDs, Active Effect ID/UUID filters, and level-specific linked/suppression rule overrides.
- Equipment growth rates: None, Normal, Double, Triple, or Custom multiplier.
- AP is awarded from the GM Materia Manager to one Actor or all Actors.
- Mastery behavior can do nothing, notify the GM, post a chat message, or create a new level-1 copy in the Actor inventory.

## Linked Support Framework

- Linked behavior activates against any valid Materia in the connected link group.
- Exact partner matching accepts multiple comma-separated Item UUIDs.
- Linked granted Item UUIDs can add temporary D&D5e Items/features to the owning Actor.
- Up to eight generic linked modifier rules can create temporary D&D5e Item enchantment changes while the link is valid.
- Modifier rules support Custom, Multiply, Add, Downgrade, Upgrade, and Override Active Effect modes.
- The generic modifier engine is designed to support campaign-specific Elemental-, Magnify-, Added Effect-, absorb-, counter-, final-action-, and similar mechanics without hard-coding specific spell names or item paths.

## Granted Abilities

- Materia can grant D&D5e Items/features while active.
- Level profiles can grant additional Items at specific levels.
- Linked Materia can grant additional Items only while their link is valid.
- Generated grants are tagged by source equipment and automatically removed/rebuilt when the equipment state changes.

## Equipment and Slot Rules

- Restrict equipment to selected Materia categories.
- Restrict equipment to comma-separated exact Materia UUIDs.
- Per-slot category restrictions.
- Per-slot exact UUID restrictions.
- Optional activation requirements for equipped state and attunement.
- Optional minimum rarity.
- Optional required D&D5e item property keys.

## Slot Appearance and Diagnostics

- Detailed Card and Compact Socket layouts.
- Vertical, horizontal, and wrapping orientations.
- Socket rings use Materia category colors.
- Slots report Active, Inactive, Suppressed, level/AP, linked-group information, and inactivity reasons.
- All configuration sections start collapsed on a fresh sheet opening.
- The Materia panel is independently scrollable.

## Permission Settings

Configure Settings includes visibility controls for Player, Trusted Player, Assistant GM, and Game Master roles.

- Player/Trusted/Assistant: Always, Owned Items Only, or Never.
- Game Master: permanently Always and not configurable to another value.

## GM Materia Library

Configure Settings → **Open Materia Library** provides:

- Create Materia.
- Duplicate world Materia definitions.
- Edit definitions.
- Copy UUIDs.
- Export the world Materia library to JSON.
- Import Materia definitions from JSON.

## GM Materia Manager & Recovery

Configure Settings → **Open Materia Manager** provides:

- Award AP to one Actor or all Actors.
- View installed Materia by Actor, equipment, slot, level, AP, and status.
- Rescan diagnostics.
- Repair a specific host or all hosts.
- Rebuild every enabled Materia host.
- Return all stored Materia from a selected equipment item.
- Detect missing template UUIDs, malformed stored Materia, hidden/orphaned slots beyond the configured count, and duplicate storage IDs.
- Stored Materia is also recovered when equipment is deleted when the Actor context remains available.
- Actor duplication/imported host snapshots retarget restoration ownership to the duplicated Actor.

## Data Safety

Custom module data is stored under:

`flags.geofen-materia-system`

The module uses event-driven hooks and does not use recurring polling timers.

## GitHub Release Assets

For release `v1.0.0`, attach exactly:

- `module.json`
- `Geofen-s-Materia-System-v1.0.0.zip`

Manifest URL:

`https://github.com/RealGeofen/Geofen-s-Materia-System/releases/latest/download/module.json`
