# Geofen's : Materia System

Version 0.1.1 targeted specifically for Foundry VTT 14.365 and D&D5e 5.3.3.

## What this test build does

- Adds a collapsible **Geofen's Materia System** panel to D&D5e Item sheets.
- Weapons and Equipment can be enabled as Materia hosts with 0–8 slots.
- Any Item can be designated as Materia.
- Materia can define:
  - Type/category.
  - Weapons/equipment restrictions.
  - Slot description text.
  - Equipment prefix.
  - Equipment suffix.
  - Whether its Active Effects are copied to the host equipment.
- Drag a configured Materia Item onto a host slot.
- Prevents one owned Materia Item UUID from being slotted into multiple pieces of equipment on the same Actor.
- Regenerates the host name and Materia description block safely from stored base data.
- Copies standard Actor Active Effects onto the host as transferable effects.
- Copies Item/enchantment effects onto the host as item enchantments where supported by D&D5e.
- Removes generated effects and text when Materia is removed or Materia hosting is disabled.
- Uses module flags instead of changing the D&D5e Item schema.
- No polling loops or recurring background timers are used.

## Basic test procedure

1. Enable the module in a D&D5e world.
2. Open an Item that will become Materia.
3. Expand **Geofen's Materia System**.
4. Check **This Item is Materia**, fill in its text/prefix/suffix, and save.
5. Optional: add a normal Active Effect to that Materia Item using D&D5e's Effects interface.
6. Open a Weapon or Equipment Item.
7. Enable Materia, choose 1–8 slots, and save.
8. Drag the configured Materia Item from an inventory or Item directory onto an empty slot.
9. Verify the equipment name and description change.
10. Equip/unequip the equipment and verify transferred Actor effects follow D&D5e suppression behavior.
11. Remove the Materia and verify its generated name/text/effects disappear.

## Important v0.1.x limitations

- Slots are independent. Linked slots/support-pair logic is planned for a later version.
- Materia AP, levels, growth, mastering, and automatic duplication are not included yet.
- This build references Materia Items by UUID; it does not remove the physical Materia Item from inventory when slotted.
- Direct enchantment copying depends on the exact structure of the enchantment Active Effect authored in D&D5e. Standard transferable Actor Active Effects are the primary v0.1.x effect path.
- The module panel is injected at the end of the D&D5e Item sheet rather than replacing the system sheet.

## Data storage

All module-owned configuration lives under:

`flags.geofen-materia-system`

The module also tags Active Effects it generates so they can be safely removed/rebuilt without deleting unrelated effects.
