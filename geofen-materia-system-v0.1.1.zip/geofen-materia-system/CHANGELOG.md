# Changelog

## 0.1.1

- Retargeted package compatibility specifically to Foundry VTT 14.365.
- Retargeted D&D5e system compatibility specifically to 5.3.3.
- Updated runtime/displayed module version to 0.1.1.
- No functional Materia behavior was removed from v0.1.0.

## 0.1.0

Initial test build.

- Equipment Materia host configuration.
- 0–8 independent Materia slots.
- Materia Item configuration.
- Drag/drop slotting and removal.
- Duplicate physical Materia UUID protection per Actor.
- Slot description generation.
- Prefix/suffix equipment naming.
- Base name/description preservation.
- Active Effect copying and cleanup.
- D&D5e equip/attunement-aware Actor effect behavior through host Item effects.
- No polling/background loops.
